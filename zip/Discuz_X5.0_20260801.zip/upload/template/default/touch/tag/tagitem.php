<?php exit('Access Denied');?>
<!--{template common/header}-->
<div class="header cl">
	<div class="mz"><a href="javascript:history.back();"><i class="dm-c-left"></i></a></div>
	<h2>
		<a href="misc.php?mod=tag">
		{lang tag}
		<!--{if $tagname}-->
		 - {$tagname}
		<!--{if $showtype == 'thread'}-->
		 - {lang related_thread}
		<!--{/if}-->
		<!--{if $showtype == 'blog'}-->
		 - {lang related_blog}
		<!--{/if}-->
		<!--{/if}-->
		</a>
	</h2>
	<div class="my"><a href="index.php"><i class="dm-house"></i></a></div>
</div>
<!--{if $tagname}-->
<div class="cl">
	<!--{if helper_access::check_module('forum') && (empty($showtype) || $showtype == 'thread')}-->
	<div class="discuz_x cl"></div>
	<div class="threadlist_box cl">
		<h2 class="xs3">
			<b>{lang related_thread}</b>
			<!--{if empty($showtype) && $threadlist}-->
			<a class="y" href="misc.php?mod=tag&id=$id&type=thread">{lang more}</a>
			<!--{/if}-->
		</h2>
		<!--{if $threadlist}-->
		<div class="threadlist cl">
			<!--{loop $threadlist $thread}-->
			<li class="list mt0 cl">
				<div class="threadlist_top cl">
					<!--{if $thread['authorid'] && $thread['author']}-->
					<a href="home.php?mod=space&uid={$thread['authorid']}" class="mimg"><!--{avatar($thread['authorid'])}--></a>
					<!--{else}-->
					<a href="javascript:;" class="mimg"><!--{avatar(0)}--></a>
					<!--{/if}-->
					<div class="muser">
						<h3>
							<!--{if $thread['authorid'] && $thread['author']}-->
							<a href="home.php?mod=space&uid={$thread['authorid']}" class="mmc">{$thread['author']}</a>
							<!--{else}-->
							{$_G['setting']['anonymoustext']}
							<!--{/if}-->
						</h3>
						<span class="mtime">{$thread['dateline']}</span>
					</div>
				</div>
				<a href="forum.php?mod=viewthread&tid=$thread['tid']" target="_blank">
				<div class="threadlist_tit cl">
					<!--{if $thread['folder'] == 'lock'}-->
					<span class="micon lock">{lang close}</span>
					<!--{elseif $thread['special'] == 1}-->
					<span class="micon">{lang thread_poll}</span>
					<!--{elseif $thread['special'] == 2}-->
					<span class="micon">{lang thread_trade}</span>
					<!--{elseif $thread['special'] == 3}-->
					<span class="micon">{lang thread_reward}</span>
					<!--{elseif $thread['special'] == 4}-->
					<span class="micon">{lang thread_activity}</span>
					<!--{elseif $thread['special'] == 5}-->
					<span class="micon">{lang thread_debate}</span>
					<!--{/if}-->
					<!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 1}-->
					<span class="micon">{lang mobtu}</span>
					<!--{/if}-->
					<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
					<span class="micon top">{lang thread_sticky}</span>
					<!--{/if}-->
					<!--{if $thread['digest'] > 0}-->
					<span class="micon digest">{lang thread_digest}</span>
					<!--{/if}-->
					<em $thread['highlight']>{$thread['subject']}</em>
				</div>
				</a>
				<div class="threadlist_foot cl">
					<ul>
						<li class="mr"><a href="forum.php?mod=forumdisplay&fid=$thread['fid']" target="_blank">$thread['forumname']</a></li>
						<li class="stats"><i class="dm-eye-fill"></i>{$thread['views']}</li>
						<li class="stats"><i class="dm-chat-s-fill"></i>{$thread['replies']}</li>
					</ul>
				</div>
			</li>
			<!--{/loop}-->
		</div>
		<!--{if $showtype && $multipage}--><div class="pgs mt10 cl">$multipage</div><!--{/if}-->
		<!--{else}-->
		<div class="empty-box"><h4>{lang no_content}</h4></div>
		<!--{/if}-->
	</div>
	<!--{/if}-->

	<!--{if helper_access::check_module('blog') && (empty($showtype) || $showtype == 'blog')}-->
	<div class="discuz_x cl"></div>
	<div class="threadlist_box cl">
		<h2 class="xs3">
			<b>{lang related_blog}</b>
			<!--{if empty($showtype) && $bloglist}-->
			<a class="y" href="misc.php?mod=tag&id=$id&type=blog">{lang more}</a>
			<!--{/if}-->
		</h2>
		<!--{if $bloglist}-->
		<div class="threadlist cl">
			<!--{loop $bloglist $blog}-->
			<li class="list mt0 cl">
				<div class="threadlist_top cl">
					<a href="home.php?mod=space&uid=$blog['uid']" target="_blank" class="mimg"><!--{avatar($blog['uid'], 'small')}--></a>
					<div class="muser">
						<h3>
							<a href="home.php?mod=space&uid=$blog['uid']" target="_blank" class="mmc">$blog['username']</a>
						</h3>
						<span class="mtime">$blog['dateline']</span>
					</div>
				</div>
				<a href="home.php?mod=space&uid=$blog['uid']&do=blog&id=$blog['blogid']" target="_blank">
				<div class="threadlist_tit cl">
					<em>$blog['subject']</em>
					<!--{if $blog['hot']}--><span class="micon">{lang hot} $blog['hot']</span><!--{/if}-->
				</div>
				<div class="threadlist_mes cl">
					$blog['message']
				</div>
				<!--{if $blog['pic']}-->
				<div class="threadlist_imgs1 cl">
					<ul>
						<li>
							<img src="$blog['pic']" />
						</li>
					</ul>
				</div>
				<!--{/if}-->
				</a>
				<div class="threadlist_foot cl">
					<ul>
						<!--{if $blog['classname']}-->
						<li class="mr">
							<a href="home.php?mod=space&uid=$blog['uid']&do=blog&classid=$blog['classid']&view=me" target="_blank">{$blog['classname']}</a>
						</li>
						<!--{/if}-->
						<li class="stats"><i class="dm-eye-fill"></i>$blog['viewnum']</li>
						<li class="stats"><i class="dm-chat-s-fill"></i>$blog['replynum']</li>
					</ul>
				</div>
			</li>
			<!--{/loop}-->
		</div>
		<!--{if $showtype && $multipage}--><div class="pgs mt10 cl">$multipage</div><!--{/if}-->
		<!--{else}-->
		<div class="empty-box"><h4>{lang no_content}</h4></div>
		<!--{/if}-->
	</div>
	<!--{/if}-->
</div>
<!--{else}-->
<form class="searchform" method="post" autocomplete="off" action="misc.php?mod=tag">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="search flex-box">
		<input value="$keyword" autocomplete="off" class="mtxt flex" name="name" id="scform_srchtxt" value="{$searchtagname}" placeholder="$searchtagname">
		<input type="submit" value="{lang search}" class="mbtn" id="scform_submit">
	</div>
</form>
<div class="bodybox empty-box cl">
	<h4 class="mt">
		{lang no_content}
	</h4>
</div>
<!--{/if}-->
<!--{template common/footer}-->