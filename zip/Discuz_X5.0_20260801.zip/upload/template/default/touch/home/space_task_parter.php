<?php exit('Access Denied');?>
<!--{eval 
	$_G['home_tpl_titles'] = array('{lang task}');
}-->
<!--{template common/header}-->
<ul class="task_parterlist">
	<!--{loop $parterlist $parter}-->
	<li>
		<a href="home.php?mod=space&uid=$parter['uid']" title="{if $parter['status'] == 1}{lang task_complete}{elseif $parter['status'] == -1}{lang task_failed}{elseif $parter['status'] == 0}{lang task_complete} $parter['csc']%{/if}"  class="task_avt">$parter['avatar']<p>$parter['username']</p></a>
	</li>
	<!--{/loop}-->
</ul>
<!--{template common/footer}-->