<?php exit('Access Denied');?>
<ul class="tb cl">
	<!--{if $_GET['op'] == 'pay'}--><li $opactives[pay]><a href="home.php?mod=spacecp&ac=payment&op=pay&order_id={$order_id}">{lang payment_pay}</a></li><!--{/if}-->
	<li $opactives[order]><a href="home.php?mod=spacecp&ac=payment&op=order">{lang payment_order}</a></li>
</ul>
