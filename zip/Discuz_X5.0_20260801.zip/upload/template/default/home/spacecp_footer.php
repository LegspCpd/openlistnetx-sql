<?php exit('Access Denied');?>
<div class="tbn">
	<h2 class="mt bbda">{lang setup}</h2>
	<ul>
		<!--{if $_G['group']['allowavatarupload']}--><li{$actives[avatar] or ''}><a href="home.php?mod=spacecp&ac=avatar">{lang memcp_avatar}</a></li><!--{/if}-->
		<li{$actives[profile] or ''}><a href="home.php?mod=spacecp&ac=profile">{lang memcp_profile}</a></li>
		<!--{if $_G['setting']['verify']['enabled'] && allowverify()}-->
			<li$actives[verify]><a href="home.php?mod=spacecp&ac=profile&op=verify">{lang memcp_verify}</a></li>
		<!--{/if}-->
		<li{$actives[credit] or ''}><a href="home.php?mod=spacecp&ac=credit">{lang memcp_credit}</a></li>
		<!--{if $_G['setting']['ec_ratio']}--><li{$actives[payment] or ''}><a href="home.php?mod=spacecp&ac=payment">{lang memcp_payment}</a></li><!--{/if}-->
		<li{$actives[usergroup] or ''}><a href="home.php?mod=spacecp&ac=usergroup">{lang memcp_usergroup}</a></li>
		<li{$actives[privacy] or ''}><a href="home.php?mod=spacecp&ac=privacy">{lang memcp_privacy}</a></li>
		
		<!--{if $_G['setting']['sendmailday']}--><li$actives[sendmail]><a href="home.php?mod=spacecp&ac=sendmail">{lang memcp_sendmail}</a></li><!--{/if}-->
		<!--
		<li{$actives[password] or ''}><a href="home.php?mod=spacecp&ac=profile&op=password">{lang password_security}</a></li>
        -->

		<!--{if $_G['setting']['creditspolicy']['promotion_visit'] || $_G['setting']['creditspolicy']['promotion_register']}-->
		<li{$actives[promotion] or ''}><a href="home.php?mod=spacecp&ac=promotion">{lang memcp_promotion}</a></li>
		<!--{/if}-->
        <li{$actives[account] or ''}><a href="home.php?mod=spacecp&ac=account">{lang memcp_account}</a></li>
		<!--{if !empty($_G['setting']['plugins']['spacecp'])}-->
			<!--{loop $_G['setting']['plugins']['spacecp'] $id $module}-->
				<!--{if in_array($module['adminid'], array(0, -1)) || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}--><li{if $_GET[id] == $id} class="a"{/if}><a href="home.php?mod=spacecp&ac=plugin&id=$id">$module[name]</a></li><!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	</ul>
</div>