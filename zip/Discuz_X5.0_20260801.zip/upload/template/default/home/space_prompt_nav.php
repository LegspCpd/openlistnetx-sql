<?php exit('Access Denied');?>
<div class="tbn">
	<h2 class="mt bbda">{lang prompt}</h2>
	<ul>
		<!--{if !empty($_G['setting']['pmstatus'])}-->
			<li $opactives['pm']><em class="notice_pm"></em><a href="home.php?mod=space&do=pm">{lang news} <!--{if $newpmcount}--><strong class="xi1">($newpmcount)</strong><!--{/if}--></a></li>
		<!--{/if}-->
		<li $opactives['all']><em class="notice_all"></em><a href="home.php?mod=space&do=notice"><!--{eval echo lang('template', 'notice_all')}--><!--{if $_G['member']['newprompt']}-->($_G['member']['newprompt'])<!--{/if}--></a></li>
		<!--{loop $_G['notice_structure'] $key $type}-->
		<li $opactives[$key]><em class="notice_$key"></em><a href="home.php?mod=space&do=notice&view=$key"><!--{eval echo lang('template', 'notice_'.$key)}--><!--{if $_G['member']['category_num'][$key]}-->($_G['member']['category_num'][$key])<!--{/if}--></a></li>
		<!--{/loop}-->		
	</ul>
</div>