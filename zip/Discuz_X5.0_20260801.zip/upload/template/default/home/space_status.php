<?php exit('Access Denied');?>
<div id="mood_mystatus" class="mtn mbn">
	<!--{if $space[spacenote]}--><a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me" title="{lang view_all_my_doings}" class="xi2">$space[spacenote]</a><!--{else}--><label for="mood_message" class="xi2">{lang no_update_record}</label><!--{/if}-->
</div>
<script type="text/javascript">
	var msgstr = '$defaultstr';
	function handlePrompt(type) {
		var msgObj = $('mood_message');
		if(type) {
			$('moodfm').className = 'hover';
			if(msgObj.value == msgstr) {
				msgObj.value = '';
				msgObj.className = 'msgfocus xg2';
			}
			if($('mood_message_menu')) {
				if($('mood_message_menu').style.display === 'block') {
					showFace('mood_message', 'mood_message', msgstr);
				}

			}
			if(BROWSER.firefox || BROWSER.chrome) {
				showFace('mood_message', 'mood_message', msgstr);
			}
		} else {
			$('moodfm').className = '';
			if(msgObj.value == ''){
				msgObj.value = msgstr;
				msgObj.className = 'xg1';
			}
		}
	}
	function reloadMood(showid) {
		var x = new Ajax();
		x.get('home.php?mod=spacecp&ac=doing&op=spacenote&inajax=1', function(s){
			$('mood_mystatus').innerHTML = '<a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me" title="{lang view_all_my_doings}" class="xi2">'+s+'</a>';
		});
		$('mood_message').value = '';
		dstrLenCalc($('mood_message'), 'maxlimit');
		handlePrompt(0);
	}
</script>
<!--{if helper_access::check_module('doing')}-->
<div id="moodfm">
	<form method="post" autocomplete="off" id="mood_addform" action="home.php?mod=spacecp&ac=doing&handlekey=doing" onsubmit="if($('mood_message').value != msgstr) {ajaxpost(this.id, 'return_doing');} else {showError('{lang content_isnull}');return false;}">
		<table cellspacing="0" cellpadding="0" width="100%">
			<tr>
				<td id="mood_statusinput" class="moodfm_input">
					<textarea name="message" id="mood_message" class="xg1" onclick="showFace(this.id, 'mood_message', msgstr);" onfocus="handlePrompt(1);" onblur="handlePrompt(0);" onkeydown="if(ctrlEnter(event, 'addsubmit_btn')){if(event.keyCode == 13 ){ doane(event);}}" onkeyup="dstrLenCalc(this, 'maxlimit');">$defaultstr</textarea>
				</td>
				<td class="moodfm_btn">
					<button type="submit" name="addsubmit_btn" id="addsubmit_btn" class="pgsbtn">{lang publish}</Button>
				</td>
			</tr>
			<tr>
				<td class="moodfm_f">
					<span class="y">{lang doing_maxlimit_char}</span>

					<!--{if !empty($_G['setting']['pluginhooks']['space_home_doing_sync_method'])}-->
						<span>
							{lang doing_sync}:
							<!--{if $_G['group']['maxsigsize']}-->
								<a title="{lang doing_update_personal_signature}" id="syn_signature" class="syn_signature" href="javascript:void(0);" onclick="checkSynSignature()">{lang doing_update_personal_signature}</a>
								<input type="hidden" name="to_signhtml" id="to_signhtml" value="0" />
							<!--{/if}-->
							<!--{hook/space_home_doing_sync_method}-->
						</span>
					<!--{else}-->
						<!--{if $_G['group']['maxsigsize']}-->
							<label for="to_sign"><input type="checkbox" name="to_signhtml" id="to_sign" class="pc" value="1" />{lang doing_update_personal_signature}</label>
						<!--{/if}-->
					<!--{/if}-->
					<div id="return_doing" class="xi1 xw1"></div>
				</td>
				<td></td>
			</tr>
		</table>
		<input type="hidden" name="addsubmit" value="true" />
		<input type="hidden" name="spacenote" value="true" />
		<input type="hidden" name="referer" value="home.php" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
	</form>
	<script type="text/javascript">
		function succeedhandle_doing(url, msg, values) {
			if(values['message']) {
				showDialog(values['message']);
				return false;
			}
			reloadMood(values['doid']);
		}
	</script>
</div>
<!--{/if}-->
