<?php exit('Access Denied');?>
<div class="tbn">
	<h2 class="mt bbda">{lang post}</h2>
	<ul>
		<!--{if $_G['setting']['guidestatus']}--><li $opactives['thread']><a href="forum.php?mod=guide&view=my">{lang all}</a></li><!--{/if}-->
		<li $opactives['activity']><a href="home.php?mod=space&do=activity&view=me">{lang activity}</a></li>
		<li $opactives['poll']><a href="home.php?mod=space&do=poll&view=me">{lang poll}</a></li>
		<li $opactives['reward']><a href="home.php?mod=space&do=reward&view=me">{lang reward}</a></li>
		<li $opactives['trade']><a href="home.php?mod=space&do=trade&view=me">{lang trade}</a></li>
		<li $opactives['debate']><a href="home.php?mod=space&do=debate&view=me">{lang debate}</a></li>		
		<!--{if !empty($_G['setting']['plugins']['space_thread'])}-->
			<!--{loop $_G['setting']['plugins']['space_thread'] $id $module}-->
				<!--{if in_array($module['adminid'], array(0, -1)) || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}--><li{if $_GET[id] == $id} class="a"{/if}><a href="home.php?mod=space&do=plugin&op=thread&id=$id">$module[name]</a></li><!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	</ul>
</div>