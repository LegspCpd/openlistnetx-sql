<?php exit('Access Denied');?>
<div id="avatardesigner">
	<div id="avatarfileselector">
		<button type="submit" id="uploadavatar" name="uploadavatar" class="uploadavatar">{lang modify_avatar}</button>
		<input type="file" name="Filedata" id="avatarfile" accept="image/*" />
	</div>
	<div id="avataradjuster">
		<img id="avatarimage" style="visibility: hidden;" />
		<canvas id="avatarcanvas" style="position: absolute; top: 0px; left: 0px;"></canvas>
		<div id="widgetparent" style="position: absolute; left: 0px; top: 0px;">
			<div id="selector" class='ui-widget-content' style="position: absolute; width: 120px; height: 120px; overflow:hidden; cursor: move; border: 1px solid lightgrey; background-color: transparent; background-image: none;">
			</div>
		</div>
		
		<div class="backfileselectiondiv">
				<input type="button" id="backfileselection" name="backfileselection" class="backfileselection" value="{lang backfileselect}" />
		</div>
		
		<div id="slider" style="height: 0px; position: absolute; right: 9px; top: 105px; width: 100px;"></div>
		
		<div class="saveAvatardiv">
			<input type="submit" id="avconfirm" name="confirm" value="{lang confirms}" class="saveAvatar" style="" />
		</div>
		
		<input type="hidden" id="avatar1" name="avatar1" />
		<input type="hidden" id="avatar2" name="avatar2" />
		<input type="hidden" id="avatar3" name="avatar3" />
	</div>
	<div id="avatardisplayer">
		<canvas id="avatardisplaycanvas"></canvas>
		
		<div class="finishbuttondiv">
				<input type="button" value="{lang finished}" class="finishbutton" onclick="location.reload(true);" />
		</div>
	</div>
</div>														

<script src="{STATICURL}js/mobile/jquery.min.js?{VERHASH}"></script>
<script type="text/javascript">
	var data = "{echo implode(",", $uc_avatarflash);}".split(',');
</script>

<link rel="stylesheet" href="{STATICURL}avatar/avatar.css?{VERHASH}" />							
<script src="{STATICURL}avatar/jquery-ui.min.js?{VERHASH}"></script>
<script src="{STATICURL}avatar/avatar.js?{VERHASH}"></script>

<iframe name="uploadframe" id="uploadframe" style="display: none;"></iframe>
<iframe name="rectframe" id="rectframe" style="display: none;"></iframe>