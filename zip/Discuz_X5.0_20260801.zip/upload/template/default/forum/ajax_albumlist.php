<?php exit('Access Denied');?>
<!--{template common/header_ajax}-->

<!--{eval $i = 0;}-->
<table cellspacing="2" cellpadding="2" class="imgl"><tr>
<!--{loop $photolist $photo}-->
	<!--{eval $i++;}-->
	<td valign="bottom" width="25%">
	<!--{if empty($_GET['from'])}-->
		<a href="javascript:;"><img src="$photo[thumburl]" title="$photo[filename]" onclick="wysiwyg ? insertText('<img src=\'$photo[url]\' border=0 style=\'max-width:400px\'/>', false) : insertText('[img]$photo[url][/img]', <!--{echo strlen($photo[url]) + 11}-->, 0);doane(event);" onload="thumbImg(this, 1)" width="110" style="height:auto" _width="110" _height="110"></a>
	<!--{else}-->
		<a href="javascript:;"><img src="$photo[thumburl]" title="$photo[filename]" onclick="albumWinCallback(currentAlbumObj, '$photo[url]', '{echo dhtmlspecialchars($photo['filename'])}')" onload="thumbImg(this, 1)" width="110" style="height:auto" _width="110" _height="110"></a>
	<!--{/if}-->
	</td>
	<!--{if $i % 4 == 0 && isset($photolist[$i])}--></tr><tr><!--{/if}-->
<!--{/loop}-->
<!--{if ($imgpad = $i % 4) > 0}--><!--{echo str_repeat('<td width="25%"></td>', 4 - $imgpad);}--><!--{/if}-->
</tr></table>
<div class="pgs cl">$multi</div>
<!--{template common/footer_ajax}-->