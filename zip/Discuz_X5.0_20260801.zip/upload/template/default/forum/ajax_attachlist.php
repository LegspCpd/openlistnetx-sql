<?php exit('Access Denied');?>
<table cellpadding="0" cellspacing="0" summary="post_attachbody" border="0" width="100%">
<!--{loop $attachlist $attach}-->
	<tbody id="attach_$attach[aid]">
		<tr>
			<td class="attswf">
				<p id="attach$attach[aid]">
					<span>$attach[filetype] <a href="javascript:;" class="xi2" id="attachname$attach[aid]" isimage="{if $attach['isimage']}1{else}0{/if}" onclick="{if $attach['isimage']}insertAttachimgTag('$attach[aid]');hideMenu('attach_preview_$attach[aid]_menu'){else}insertAttachTag('$attach[aid]'){/if};doane(event);" title="{lang upload_msg}" {if $attach['isimage']}onmouseout="hideMenu('attach_preview_$attach[aid]_menu');" onmouseover="showMenu({'ctrlid':this.id,'menuid':'attach_preview_$attach[aid]_menu','pos':'!'});"{/if}>{$attach[filename]}</a></span>
					<!--{if $_G['setting']['allowattachurl']}-->
						<a href="javascript:;" class="atturl" title="{lang e_attach_url}" onclick="insertText('attach://$attach[aid].{echo fileext($attach[filenametitle])}');doane(event);"><img src="{IMGDIR}/attachurl.gif" /></a>
						<!--{if ($attachmcode = parseattachmedia($attach))}--><a href="javascript:;" class="atturl" title="{lang e_attach_mediacode}" onclick="insertText('$attachmcode');doane(event);"><img src="{IMGDIR}/attachmediacode.gif" /></a><!--{/if}-->
					<!--{/if}-->
					<!--{if $attach['pid']}-->
						<input type="hidden" name="attachupdate[{$attach[aid]}]" id="attachupdate{$attach[aid]}" size="2" />&nbsp;
						<!--{if !empty($allowuploadnum)}--><a href="javascript:;" onclick="uploadWindow(function (aid, url, name){$('attachupdate$attach[aid]').value = aid;$('attachname$attach[aid]').title = '';$('attachname$attach[aid]').innerHTML = name;$('attachname$attach[aid]').onmouseover=null}, 'file');return false;">{lang update}</a><!--{/if}-->
						<!--{if $_G['forum']['picstyle'] && $attach['thumb']}-->
							&nbsp;<a href="forum.php?mod=ajax&action=setthreadcover&aid={$attach[aid]}&fid=$_G['fid']" onclick="ajaxmenu(this);doane(event);">{lang set_cover}</a>
						<!--{/if}-->
					<!--{/if}-->
				</p>
				<span id="attachupdate$attach[aid]"></span>
				<!--{if $attach['isimage']}-->
				<div id="attach_preview_$attach[aid]_menu" class="attach_preview" style="display:none"><img src="{echo getforumimg($attach[aid], 1, 300, 300, 'fixnone')}&ramdom={echo random(5)}" id="image_$attach[aid]" cwidth="{if $attach[width] < 300}$attach[width]{else}300{/if}"/></div>
				<!--{/if}-->
				<!--{if $_GET[result] == 'simple'}-->
				<input type="hidden" name="attachnew[{$attach[aid]}][description]" value="" />
				<input type="hidden" name="attachnew[{$attach[aid]}][readperm]" value="" />
				<input type="hidden" name="attachnew[{$attach[aid]}][price]" value="" />
				<!--{/if}-->
			</td>
			<!--{if $_GET[result] != 'simple'}-->
				<td class="atds"><input type="text" name="attachnew[{$attach[aid]}][description]" class="px" value="$attach[description]" size="6" /></td>
				<!--{if $_G['group']['allowsetattachperm']}-->
				<td class="attv">
					<!--{if $_G['cache']['groupreadaccess']}-->
					<select class="ps" name="attachnew[{$attach[aid]}][readperm]" id="readperm" style="width:90px">
							<option value="">{lang unlimited}</option>
						<!--{loop $_G['cache']['groupreadaccess'] $val}-->
							<option value="$val[readaccess]" title="{lang readperm}: $val[readaccess]"{if $attach[readperm] == $val[readaccess]} selected{/if}>$val[grouptitle]</option>
						<!--{/loop}-->
							<option value="255"{if $attach[readperm] == 255} selected{/if}>{lang highest_right}</option>
					</select>
					<!--{/if}-->
				</td>
				<!--{/if}-->
				<!--{if $_G['group']['maxprice']}--><td class="attpr"><input type="text" name="attachnew[{$attach[aid]}][price]" class="px" value="$attach[price]" size="1" /></td><!--{/if}-->
			<!--{/if}-->
			<td class="attc"><a href="javascript:;" class="d" onclick="delAttach($attach[aid],{if !$attach[pid]}1{else}0{/if});return false;" title="{lang e_attach_del}">{lang e_attach_del}</a></td>
		</tr>
	</tbody>
<!--{/loop}-->
</table>
<!--{if $_G[inajax]}-->
	<script type="text/javascript" reload="1">
	ATTACHNUM['attachunused'] += <!--{echo count($attachlist)}-->;
	updateattachnum('attach');
	if($('attachlimitnotice')) {
		ajaxget('forum.php?mod=ajax&action=updateattachlimit&fid=' + fid, 'attachlimitnotice');
	}
	</script>
<!--{/if}-->