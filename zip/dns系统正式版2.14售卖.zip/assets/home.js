layui.define(['element','layer'],function(exports){

    var $ = layui.$, $body = $('body'),
        element = layui.element,
        layer = layui.layer;

    var screen_size = {
        pc : [991, -1],
        pad : [768, 990],
        mobile : [0, 767]
    }

    var getDevice = function(){
        var width = $(window).width();
        for (var i in screen_size) {
            var sizes = screen_size[i],
                min = sizes[0],
                max = sizes[1];
            if(max == -1) max = width;
            if(min <= width && max >= width){
                return i;
            }
        }
        return null;
    }

    var isDevice = function(label){
        return getDevice() == label;
    }

    var isMobile = function(){
        return isDevice('mobile');
    }

    var Tab = function(el){
        this.el = el;
        this.urls = [];
    }

    Tab.prototype.content = function(src) {
        var iframe = document.createElement("iframe");
        iframe.setAttribute("frameborder", "0");
        iframe.setAttribute("src", src);
        iframe.setAttribute("data-id", this.urls.length);
        return iframe.outerHTML;
    };

    Tab.prototype.is = function(url) {
        return (this.urls.indexOf(url) !== -1)
    };

    Tab.prototype.add = function(title, url) {
        if(this.is(url)) return false;
        this.urls.push(url);
        element.tabAdd(this.el, {
            title : title
            ,content : this.content(url)
            ,id : url
        });
        this.change(url);
    };

    Tab.prototype.change = function(url) {
        element.tabChange(this.el, url);
    };

    Tab.prototype.delete = function(url) {
        element.tabDelete(this.el, url);
    };

    Tab.prototype.onChange = function(callback){
        element.on('tab('+this.el+')', callback);
    };

    Tab.prototype.onDelete = function(callback) {
        var self = this;
        element.on('tabDelete('+this.el+')', function(data){
            var i = data.index;
            self.urls.splice(i,1);
            callback && callback(data);
        });
    };

    var Home = function(){

        var $layuiBody = $('.layui-body');

        // 处理所有导航链接的点击事件
        $('#Nav a').on('click',function(event){
            var $this = $(this), url = $this.data('url');
            
            if( url && url!=='javascript:;' ){
                event.preventDefault(); // 阻止默认跳转行为
                // 直接替换layui-body中的内容，不显示标签
                $layuiBody.html('<iframe frameborder="0" src="' + url + '" style="width:100%;height:100%"></iframe>');
                
                // 添加选中样式
                $('#Nav li, #Nav dd').removeClass('layui-this');
                $this.closest('li.layui-nav-item').addClass('layui-this');
                if($this.parent().is('dd')) {
                    $this.parent('dd').addClass('layui-this');
                }
            }
        });
        
        // 监听Layui导航菜单的点击事件，确保父级菜单能正常展开/折叠
        layui.element.on('nav(Nav)', function(elem) {
            // 这里可以添加额外的导航逻辑，但不干涉默认的展开/折叠行为
        });

        // 默认触发第一个导航项的点击事件
        $('#Nav li.layui-nav-item:eq(0) > a').trigger('click');

        this.slideSideBar();
    }

    Home.prototype.slideSideBar = function() {
        var $slideSidebar = $('.slide-sidebar'),
            $pageContainer = $('.layui-body'),
            $mobileMask = $('.mobile-mask');

        var isFold = false;
        $slideSidebar.click(function(e){
            e.preventDefault();
            var $this = $(this), $icon = $this.find('i'),
                $admin = $body.find('.layui-layout-admin');
            var toggleClass = isMobile() ? 'fold-side-bar-xs' : 'fold-side-bar';
            if($icon.hasClass('ai-menufold')){
                $icon.removeClass('ai-menufold').addClass('ai-menuunfold');
                $admin.addClass(toggleClass);
                isFold = true;
                if(isMobile()) $mobileMask.show();
            }else{
                $icon.removeClass('ai-menuunfold').addClass('ai-menufold');
                $admin.removeClass(toggleClass);
                isFold = false;
                if(isMobile()) $mobileMask.hide();
            }
        });

        var tipIndex;
        // 菜单收起后的模块信息小提示 - 仅在非移动端显示
        $('#Nav li > a').hover(function(){
            var $this = $(this);
            if(isFold && !isMobile()) {
                tipIndex = layer.tips($this.find('em').text(),$this);
            }
        }, function(){
            if(isFold && !isMobile() && tipIndex ){
                layer.close(tipIndex);
                tipIndex = null
            }
        })

        if(isMobile()){
            $mobileMask.click(function(){
                $slideSidebar.trigger('click');
            });
        }
    }

    exports('home',new Home);
});