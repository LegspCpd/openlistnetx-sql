<?php
// 启动会话
session_start();

// 检查用户是否已登录
if (!isset($_SESSION['user_id'])) {
    // 未登录，重定向到登录页面
    header('Location: login.php');
    exit;
}

// 引入配置文件
require_once 'config.php';

// 连接数据库
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("连接数据库失败: " . $conn->connect_error);
}

// 获取用户ID
$user_id = $_SESSION['user_id'];
$user_sql = "SELECT id, username FROM user WHERE id = '$user_id'";
$user_result = $conn->query($user_sql);
$user = $user_result->fetch_assoc();
$username = $user['username'];

// 获取工单列表
$tickets = [];
$ticket_details = null;
$ticket_replies = [];

// 获取所有工单
$tickets_sql = "SELECT * FROM tickets WHERE user_id = '$user_id' ORDER BY created_at DESC";
$tickets_result = $conn->query($tickets_sql);
while ($ticket = $tickets_result->fetch_assoc()) {
    $tickets[] = $ticket;
}

// 获取工单详情
if (isset($_GET['view_ticket'])) {
    $ticket_id = $_GET['view_ticket'];
    $ticket_sql = "SELECT * FROM tickets WHERE id = '$ticket_id' AND user_id = '$user_id'";
    $ticket_result = $conn->query($ticket_sql);
    $ticket_details = $ticket_result->fetch_assoc();
    
    // 获取工单回复
    if ($ticket_details) {
        $replies_sql = "SELECT * FROM ticket_replies WHERE ticket_id = '$ticket_id' ORDER BY created_at ASC";
        $replies_result = $conn->query($replies_sql);
        while ($reply = $replies_result->fetch_assoc()) {
            $ticket_replies[] = $reply;
        }
    }
}

// 处理工单提交
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['reply_ticket'])) {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $image = '';
    
    // 处理图片上传
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $target_file = $target_dir . time() . '_' . basename($_FILES["image"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        
        // 检查文件是否为图片
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if($check !== false) {
            // 检查文件大小
            if ($_FILES["image"]["size"] < 5000000) {
                // 允许的文件格式
                if($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "gif") {
                    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                        $image = $target_file;
                    }
                }
            }
        }
    }
    
    // 插入工单
    $ticket_sql = "INSERT INTO tickets (user_id, title, content) VALUES ('$user_id', '$title', '$content')";
    if ($conn->query($ticket_sql) === TRUE) {
        $ticket_id = $conn->insert_id;
        
        // 如果有图片，插入回复
        if (!empty($image)) {
            $reply_sql = "INSERT INTO ticket_replies (ticket_id, user_id, content, image, is_admin) VALUES ('$ticket_id', '$user_id', '$content', '$image', 0)";
            $conn->query($reply_sql);
        }
        
        $success_message = "工单提交成功！";
        // 刷新页面，显示工单列表
        header('Location: tickets.php');
        exit;
    } else {
        $error_message = "工单提交失败: " . $conn->error;
    }
}

// 处理工单回复
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reply_ticket'])) {
    $ticket_id = $_POST['ticket_id'];
    $content = $_POST['content'];
    $image = '';
    
    // 检查工单状态
    $check_status_sql = "SELECT status FROM tickets WHERE id = '$ticket_id' AND user_id = '$user_id'";
    $check_status_result = $conn->query($check_status_sql);
    $ticket_status = $check_status_result->fetch_assoc();
    
    if ($ticket_status['status'] == 'closed') {
        $error_message = "该工单已解决，无法再添加回复。";
        header('Location: tickets.php?view_ticket=' . $ticket_id);
        exit;
    }
    
    // 处理图片上传
    if (isset($_FILES['reply_image']) && $_FILES['reply_image']['error'] == 0) {
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $target_file = $target_dir . time() . '_' . basename($_FILES["reply_image"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        
        // 检查文件是否为图片
        $check = getimagesize($_FILES["reply_image"]["tmp_name"]);
        if($check !== false) {
            // 检查文件大小
            if ($_FILES["reply_image"]["size"] < 5000000) {
                // 允许的文件格式
                if($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "gif") {
                    if (move_uploaded_file($_FILES["reply_image"]["tmp_name"], $target_file)) {
                        $image = $target_file;
                    }
                }
            }
        }
    }
    
    // 插入回复
    $reply_sql = "INSERT INTO ticket_replies (ticket_id, user_id, content, image, is_admin) VALUES ('$ticket_id', '$user_id', '$content', '$image', 0)";
    if ($conn->query($reply_sql) === TRUE) {
        $success_message = "回复提交成功！";
        // 刷新页面，显示工单详情
        header('Location: tickets.php?view_ticket=' . $ticket_id);
        exit;
    } else {
        $error_message = "回复提交失败: " . $conn->error;
    }
}

// 关闭数据库连接
$conn->close();
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>工单管理</title>
    <link rel="stylesheet" href="assets/css/layui.css">
    <style>
        body {
            background-color: #f0f2f5;
        }
        .container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
        }
        .header-actions {
            text-align: right;
            margin-bottom: 20px;
        }
        .message {
            margin: 10px 0;
            padding: 10px;
            border-radius: 4px;
        }
        .success-message {
            background-color: #f0f9eb;
            color: #67c23a;
            border: 1px solid #e1f5cb;
        }
        .error-message {
            background-color: #fef0f0;
            color: #f56c6c;
            border: 1px solid #fbc4c4;
        }
        .ticket-list {
            margin-bottom: 30px;
        }
        
        /* 响应式设计 */
        @media screen and (max-width: 768px) {
            .container {
                margin: 10px;
                padding: 15px;
            }
            .layui-card-header {
                padding: 12px 15px;
            }
            .layui-card-body {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 消息提示 -->
        <?php if (isset($success_message)): ?>
            <div class="message success-message">
                <i class="layui-icon layui-icon-success"></i> <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        <?php if (isset($error_message)): ?>
            <div class="message error-message">
                <i class="layui-icon layui-icon-error"></i> <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <!-- 创建工单按钮 -->
        <div class="header-actions">
            <?php if (!$ticket_details && !isset($_GET['action'])): ?>
                <a href="tickets.php?action=create" class="layui-btn layui-btn-normal">
                    <i class="layui-icon layui-icon-add-circle"></i> 创建工单
                </a>
            <?php elseif (isset($_GET['action']) && $_GET['action'] == 'create'): ?>
                <a href="tickets.php" class="layui-btn layui-btn-primary">返回工单列表</a>
            <?php endif; ?>
        </div>
        
        <!-- 工单详情 -->
        <?php if ($ticket_details): ?>
            <div style="display: flex; justify-content: flex-end; margin-bottom: 15px;">
                <a href="tickets.php" class="layui-btn layui-btn-primary">返回工单列表</a>
            </div>
            
            <div class="layui-card" style="margin-bottom: 20px;">
                <div class="layui-card-header">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <h3 style="margin: 0; font-size: 18px;"><?php echo $ticket_details['title']; ?></h3>
                        <?php if ($ticket_details['status'] == 'open'): ?>
                            <span class="layui-badge layui-bg-green">待处理</span>
                        <?php elseif ($ticket_details['status'] == 'processing'): ?>
                            <span class="layui-badge layui-bg-blue">处理中</span>
                        <?php else: ?>
                            <span class="layui-badge layui-bg-gray">已解决</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="layui-card-body">
                    <div style="color: #666; margin-bottom: 15px;">
                        创建者: <?php echo $username; ?> | 创建时间: <?php echo $ticket_details['created_at']; ?>
                    </div>
                    <p><?php echo $ticket_details['content']; ?></p>
                    <?php
                    // 检查是否有相关的图片回复
                    foreach ($ticket_replies as $reply) {
                        if (!empty($reply['image']) && !$reply['is_admin']) {
                            echo '<div style="margin-top: 10px;">';
                            echo '<img src="' . $reply['image'] . '" alt="工单图片" style="max-width: 100%; border-radius: 4px;">';
                            echo '</div>';
                            break;
                        }
                    }
                    ?>
                </div>
            </div>
            
            <div class="layui-card" style="margin-bottom: 20px;">
                <div class="layui-card-header">
                    <h3 style="margin: 0; font-size: 16px;">沟通记录</h3>
                </div>
                <div class="layui-card-body">
                    <?php if (count($ticket_replies) > 0): ?>
                        <?php foreach ($ticket_replies as $reply): ?>
                            <div class="layui-bg-gray" style="padding: 15px; margin-bottom: 15px; border-radius: 4px;">
                                <div style="color: #666; margin-bottom: 10px; font-size: 14px;">
                                    <?php echo $reply['is_admin'] ? '管理员' : '我'; ?> | <?php echo $reply['created_at']; ?>
                                </div>
                                <div><?php echo $reply['content']; ?></div>
                                <?php if (!empty($reply['image'])): ?>
                                    <div style="margin-top: 10px;">
                                        <img src="<?php echo $reply['image']; ?>" alt="回复图片" style="max-width: 100%; border-radius: 4px;">
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div style="text-align: center; color: #999; padding: 30px 0;">
                            暂无回复记录
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <?php if ($ticket_details['status'] != 'closed'): ?>
            <div class="layui-card">
                <div class="layui-card-header">
                    <h3 style="margin: 0; font-size: 16px;">添加回复</h3>
                </div>
                <div class="layui-card-body">
                    <form class="layui-form" action="tickets.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="ticket_id" value="<?php echo $ticket_id; ?>">
                        <input type="hidden" name="reply_ticket" value="1">
                        
                        <div class="layui-form-item">
                            <div class="layui-input-block">
                                <textarea name="content" required lay-verify="required" placeholder="请输入回复内容..." class="layui-textarea" style="min-height: 120px;"></textarea>
                            </div>
                        </div>
                        
                        <div class="layui-form-item">
                            <div class="layui-input-block">
                                <button type="button" class="layui-btn" id="reply-upload-btn">
                                    <i class="layui-icon layui-icon-upload"></i> 选择图片
                                </button>
                                <input type="file" name="reply_image" id="reply_image" style="display: none;" accept="image/*">
                            </div>
                            <div id="reply-image-preview" style="margin-top: 10px;">
                                <!-- 图片预览会在这里显示 -->
                            </div>
                        </div>
                        
                        <div class="layui-form-item">
                            <div class="layui-input-block">
                                <button type="submit" class="layui-btn layui-btn-normal">提交回复</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php else: ?>
            <div class="layui-card">
                <div class="layui-card-header">
                    <h3 style="margin: 0; font-size: 16px;">回复提示</h3>
                </div>
                <div class="layui-card-body">
                    <p class="layui-text layui-text-gray">该工单已解决，无法再添加回复。</p>
                </div>
            </div>
            <?php endif; ?>
        <?php elseif (isset($_GET['action']) && $_GET['action'] == 'create'): ?>
            <!-- 提交工单表单 -->
            <div style="margin-top: 20px;">
                <h3>创建新工单</h3>
                <form class="layui-form" action="tickets.php" method="post" enctype="multipart/form-data">
                    <div class="layui-form-item">
                        <label class="layui-form-label">工单标题</label>
                        <div class="layui-input-block">
                            <input type="text" name="title" required lay-verify="required" placeholder="请输入工单标题" autocomplete="off" class="layui-input">
                        </div>
                    </div>
                    
                    <div class="layui-form-item">
                        <label class="layui-form-label">问题描述</label>
                        <div class="layui-input-block">
                            <textarea name="content" required lay-verify="required" placeholder="请输入问题描述" class="layui-textarea" style="min-height: 150px;"></textarea>
                        </div>
                    </div>
                    
                    <div class="layui-form-item">
                        <label class="layui-form-label">上传图片（可选）</label>
                        <div class="layui-input-block">
                            <div class="layui-upload">
                                <button type="button" class="layui-btn" id="upload-btn">
                                    <i class="layui-icon layui-icon-upload"></i> 选择文件
                                </button>
                                <span id="file-name" style="margin-left: 10px; color: #666;">未选择任何文件</span>
                                <input type="file" name="image" id="image" style="display: none;" accept="image/*">
                            </div>
                            <div style="margin-top: 10px; font-size: 12px; color: #999;">
                                支持JPG, JPEG, PNG, GIF格式，最大不超过5MB
                            </div>
                            <div id="image-preview" style="margin-top: 15px;">
                                <!-- 图片预览会在这里显示 -->
                            </div>
                        </div>
                    </div>
                    
                    <div class="layui-form-item">
                        <div class="layui-input-block" style="text-align: right;">
                            <button type="submit" class="layui-btn layui-btn-blue">
                                <i></i> 提交工单
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <!-- 工单列表 -->
            <div class="ticket-list">
                <h3>我的工单</h3>
                <?php if (count($tickets) > 0): ?>
                    <table class="layui-table" lay-size="sm">
                        <thead>
                            <tr>
                                <th>标题</th>
                                <th>状态</th>
                                <th>创建时间</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tickets as $ticket): ?>
                                <tr>
                                    <td><?php echo $ticket['title']; ?></td>
                                    <td>
                                        <?php if ($ticket['status'] == 'open'): ?>
                                            <span class="layui-badge layui-bg-green">待处理</span>
                                        <?php elseif ($ticket['status'] == 'processing'): ?>
                                            <span class="layui-badge layui-bg-blue">处理中</span>
                                        <?php else: ?>
                                            <span class="layui-badge layui-bg-gray">已解决</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $ticket['created_at']; ?></td>
                                    <td>
                                        <a href="tickets.php?view_ticket=<?php echo $ticket['id']; ?>" class="layui-btn layui-btn-xs layui-btn-normal">查看详情</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="message success-message">
                        <i class="layui-icon layui-icon-info"></i> 暂无工单记录，点击右上角按钮创建新工单
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <script src="assets/layui.js"></script>
    <script>
        layui.use(['form', 'layer'], function() {
            var form = layui.form;
            var layer = layui.layer;
            
            // 图片上传预览
            if (document.getElementById('upload-btn')) {
                document.getElementById('upload-btn').addEventListener('click', function() {
                    document.getElementById('image').click();
                });
                
                document.getElementById('image').addEventListener('change', function(e) {
                    var file = e.target.files[0];
                    if (file) {
                        // 更新文件名显示
                        document.getElementById('file-name').textContent = file.name;
                        
                        // 显示图片预览
                        var reader = new FileReader();
                        reader.onload = function(e) {
                            var preview = document.getElementById('image-preview');
                            preview.innerHTML = '<img src="' + e.target.result + '" alt="预览图片" style="max-width: 200px; max-height: 200px; border-radius: 4px;">';
                        };
                        reader.readAsDataURL(file);
                    } else {
                        // 重置文件名显示
                        document.getElementById('file-name').textContent = '未选择任何文件';
                        // 清空预览
                        document.getElementById('image-preview').innerHTML = '';
                    }
                });
            }
            
            // 回复图片上传预览
            if (document.getElementById('reply-upload-btn')) {
                document.getElementById('reply-upload-btn').addEventListener('click', function() {
                    document.getElementById('reply_image').click();
                });
                
                document.getElementById('reply_image').addEventListener('change', function(e) {
                    var file = e.target.files[0];
                    if (file) {
                        var reader = new FileReader();
                        reader.onload = function(e) {
                            var preview = document.getElementById('reply-image-preview');
                            preview.innerHTML = '<img src="' + e.target.result + '" alt="预览图片">';
                        };
                        reader.readAsDataURL(file);
                    }
                });
            }
            
            // 表单验证
            form.verify({
                title: function(value) {
                    if (value.length < 2) {
                        return '工单标题至少需要2个字符';
                    }
                },
                content: function(value) {
                    if (value.length < 5) {
                        return '工单内容至少需要5个字符';
                    }
                }
            });
        });
    </script>
     <script type="text/javascript">
        // 禁止右键点击
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });
        
        // 禁止F12键
        document.addEventListener('keydown', function(e) {
            // F12键的keyCode是123
            if (e.keyCode === 123) {
                e.preventDefault();
            }
            // 禁止Ctrl+Shift+I
            if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
                e.preventDefault();
            }
            // 禁止Ctrl+U (查看源代码)
            if (e.ctrlKey && e.keyCode === 85) {
                e.preventDefault();
            }
        });
        
        // 防止通过浏览器菜单打开开发者工具的简单防护
        // 这不能完全阻止，但可以增加难度
        window.ondevtoolschange = function(open) {
            if (open) {
                window.close(); // 如果打开了开发者工具，关闭页面
                // 或者可以使用 location.reload() 刷新页面
            }
        };
    </script>
</body>
</html>