<?php
// 引入配置文件
require_once 'config.php';

// 从数据库获取当前模板设置
$template = 'default'; // 默认模板

try {
    $db = getDB();
    $stmt = $db->prepare("SELECT `value` FROM `system_settings` WHERE `key` = 'current_template'");
    $stmt->execute();
    $result = $stmt->fetch();
    if ($result) {
        $template = $result['value'];
    }
} catch (PDOException $e) {
    // 数据库查询失败，使用默认模板
}

// 验证模板是否存在，不存在则使用默认模板
$templatePath = "template/{$template}/index.php";
if (!file_exists($templatePath)) {
    $templatePath = "template/default/index.php";
}

// 加载选中的模板
include $templatePath;
?>