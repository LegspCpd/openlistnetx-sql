<?php
// 初始化错误信息
$errorMessage = "";
$successMessage = "";

// 检查是否已登录（这里需要根据实际的登录逻辑进行调整）
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// 数据库连接
require_once 'config.php';

// 处理密码修改请求
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userId = $_SESSION['user_id'];
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    
    // 验证输入
    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        $errorMessage = "所有字段均为必填项";
    } elseif ($newPassword != $confirmPassword) {
        $errorMessage = "两次输入的新密码不一致";
    } elseif (strlen($newPassword) < 6) {
        $errorMessage = "新密码长度至少为6位";
    } else {
        try {
            $db = getDB();
            
            // 验证当前密码
            $stmt = $db->prepare("SELECT password FROM user WHERE id = ?");
            $stmt->execute([$userId]);
            $result = $stmt->fetch();
            
            if ($result) {
                $hashedPassword = $result['password'];
                
                // 这里需要根据实际的密码存储方式进行验证
                // 如果密码是明文存储（不推荐）
                if ($currentPassword == $hashedPassword) {
                    // 更新密码
                    $updateStmt = $db->prepare("UPDATE user SET password = ? WHERE id = ?");
                    if ($updateStmt->execute([$newPassword, $userId])) {
                        $successMessage = "密码修改成功";
                    } else {
                        $errorMessage = "密码修改失败";
                    }
                } else {
                    $errorMessage = "当前密码错误";
                }
            } else {
                $errorMessage = "用户不存在";
            }
        } catch (PDOException $e) {
            $errorMessage = "数据库错误: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>修改密码</title>
    <link rel="shortcut icon" href="https://q2.qlogo.cn/headimg_dl?dst_uin=2517583153&spec=100" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/layui.css">
    <style>
        body {
            background-color: #f2f2f2;
        }
        .layui-container {
            margin-top: 60px;
            margin-bottom: 60px;
        }
        .layui-card {
            box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
        }
        .layui-card-header {
            font-size: 16px;
            font-weight: 600;
        }
        .layui-form-item {
            margin-bottom: 20px;
        }
        .layui-form-label {
            width: 120px;
        }
        .layui-input-block {
            margin-left: 150px;
        }
        .layui-btn {
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <div class="layui-container">
        <div class="layui-row">
            <div class="layui-col-md6 layui-col-md-offset3">
                <div class="layui-card">
                    <div class="layui-card-header">
                        <i class="layui-icon layui-icon-password"></i> 修改密码
                    </div>
                    <div class="layui-card-body">
                        <form class="layui-form" method="post">
                            <div class="layui-form-item">
                                <div class="layui-input-inline" style="width: 100%; max-width: 300px; margin-left: 50%; transform: translateX(-50%);">
                                    <input type="text" name="current_password" id="current_password" lay-verify="required" placeholder="请输入当前密码" class="layui-input">
                                </div>
                            </div>
                            
                            <div class="layui-form-item">
                                <div class="layui-input-inline" style="width: 100%; max-width: 300px; margin-left: 50%; transform: translateX(-50%);">
                                    <input type="text" name="new_password" id="new_password" lay-verify="required|min:6" placeholder="请输入新密码（至少6位）" class="layui-input">
                                </div>
                            </div>
                            
                            <div class="layui-form-item">
                                <div class="layui-input-inline" style="width: 100%; max-width: 300px; margin-left: 50%; transform: translateX(-50%);">
                                    <input type="text" name="confirm_password" id="confirm_password" lay-verify="required|confirm:new_password" placeholder="请再次输入新密码" class="layui-input">
                                </div>
                            </div>
                            
                            <div class="layui-form-item">
                                <div style="text-align: center; margin-top: 20px;">
                                    <button class="layui-btn" lay-submit lay-filter="changePassword">修改密码</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/layui.js"></script>
    <script type="text/javascript">
        layui.use(['form', 'layer'], function() {
            var form = layui.form;
            var layer = layui.layer;
            
            // 自定义验证规则
            form.verify({
                confirm: function(value, item) {
                    var newPassword = document.getElementById('new_password').value;
                    if (value !== newPassword) {
                        return '两次输入的密码不一致';
                    }
                }
            });
            
            // 显示错误信息
            <?php if (!empty($errorMessage)): ?>
            layer.msg('<?php echo $errorMessage;?>', {
                icon: 5,
                time: 3000,
                anim: 6
            });
            <?php endif;?>
            
            // 显示成功信息
            <?php if (!empty($successMessage)): ?>
            layer.msg('<?php echo $successMessage;?>', {
                icon: 6,
                time: 3000
            });
            <?php endif;?>
            
            // 监听表单提交
            form.on('submit(changePassword)', function(data) {
                // 这里可以添加额外的验证逻辑
                return true;
            });
        });
        
        // 禁止右键点击
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });
        
        // 禁止F12键
        document.addEventListener('keydown', function(e) {
            if (e.keyCode === 123) {
                e.preventDefault();
            }
            if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
                e.preventDefault();
            }
            if (e.ctrlKey && e.keyCode === 85) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>