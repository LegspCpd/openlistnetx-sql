<?php

/**
 * DNS系统配置文件
 */

// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', 'c9_h2u6_my');
define('DB_USER', 'c9_h2u6_my');
define('DB_PASS', 'c9_h2u6_my');
define('DB_CHARSET', 'utf8mb4');

// 系统配置
define('SYSTEM_NAME', 'DNS管理系统');
define('SYSTEM_VERSION', '1.0.0');
define('BASE_URL', '/');

// 会话配置
define('SESSION_TIMEOUT', 3600); // 1小时

// Cloudflare API配置（默认值，可通过管理页面修改）
define('CLOUDFLARE_API_URL', 'https://api.cloudflare.com/client/v4');

// 错误报告配置
error_reporting(E_ALL);
ini_set('display_errors', 1);

/**
 * 数据库连接函数
 * @return PDO 数据库连接对象
 */
function getDB() {
    static $db = null;
    
    if ($db === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        
        try {
            $db = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die('数据库连接失败: ' . $e->getMessage());
        }
    }
    
    return $db;
}

/**
 * 从数据库获取设置值
 * @param string $name 设置名称
 * @param mixed $default 默认值
 * @return mixed 设置值
 */
function getSetting($name, $default = null) {
    $db = getDB();
    $stmt = $db->prepare("SELECT value FROM settings WHERE name = ?");
    $stmt->execute([$name]);
    $result = $stmt->fetch();
    
    return $result ? $result['value'] : $default;
}

/**
 * 设置设置值
 * @param string $name 设置名称
 * @param mixed $value 设置值
 * @return bool 是否成功
 */
function setSetting($name, $value) {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO settings (name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?");
    return $stmt->execute([$name, $value, $value]);
}

/**
 * 获取Cloudflare配置
 * @return array Cloudflare配置
 */
function getCloudflareConfig() {
    $db = getDB();
    $stmt = $db->query("SELECT * FROM cloudflare_config ORDER BY id DESC LIMIT 1");
    return $stmt->fetch() ?: [];
}

/**
 * 保存Cloudflare配置
 * @param array $config Cloudflare配置
 * @return bool 是否成功
 */
function saveCloudflareConfig($config) {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO cloudflare_config (email, api_key, api_token) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE email = ?, api_key = ?, api_token = ?");
    
    // 处理可能为空的api_token
    $api_token = isset($config['api_token']) ? $config['api_token'] : null;
    
    return $stmt->execute([
        $config['email'],
        $config['api_key'],
        $api_token,
        $config['email'],
        $config['api_key'],
        $api_token
    ]);
}

/**
 * 获取阿里云配置
 * @return array 阿里云配置
 */
function getAliyunConfig() {
    $db = getDB();
    $stmt = $db->query("SELECT * FROM aliyun_config ORDER BY id DESC LIMIT 1");
    return $stmt->fetch() ?: [];
}

/**
 * 保存阿里云配置
 * @param array $config 阿里云配置
 * @return bool 是否成功
 */
function saveAliyunConfig($config) {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO aliyun_config (access_key_id, access_key_secret) VALUES (?, ?) ON DUPLICATE KEY UPDATE access_key_id = ?, access_key_secret = ?");
    
    return $stmt->execute([
        $config['access_key_id'],
        $config['access_key_secret'],
        $config['access_key_id'],
        $config['access_key_secret']
    ]);
}

/**
 * 获取腾讯云DNSPod配置
 * @return array 腾讯云DNSPod配置
 */
function getDnspodConfig() {
    $db = getDB();
    $stmt = $db->query("SELECT * FROM dnspod_config ORDER BY id DESC LIMIT 1");
    return $stmt->fetch() ?: [];
}

/**
 * 保存腾讯云DNSPod配置
 * @param array $config 腾讯云DNSPod配置
 * @return bool 是否成功
 */
function saveDnspodConfig($config) {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO dnspod_config (secret_id, secret_key) VALUES (?, ?) ON DUPLICATE KEY UPDATE secret_id = ?, secret_key = ?");
    
    return $stmt->execute([
        $config['secret_id'],
        $config['secret_key'],
        $config['secret_id'],
        $config['secret_key']
    ]);
}

/**
 * 重定向函数
 * @param string $url 重定向URL
 */
function redirect($url) {
    header('Location: ' . $url);
    exit;
}

/**
 * 显示消息
 * @param string $message 消息内容
 * @param string $type 消息类型（success, error, warning, info）
 */
function showMessage($message, $type = 'info') {
    $_SESSION['message'] = ['content' => $message, 'type' => $type];
}

/**
 * 获取并清除消息
 * @return array|null 消息数组或null
 */
function getMessage() {
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        unset($_SESSION['message']);
        return $message;
    }
    return null;
}

?>