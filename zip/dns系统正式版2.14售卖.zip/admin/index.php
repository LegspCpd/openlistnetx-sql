<?php 
Define('PM_CALL',true);
Define('INC_CALL',true);
include dirname(__FILE__).('../config.php');
header('Location:'. htmlspecialchars_decode('login.php').'');

?>