<?php
// 开启会话
session_start();
require_once '../config.php';
// 检查用户是否已经登录
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in']!== true) {
    // 如果用户未登录，重定向到登录页面
    header('Location: login.php');
    exit;
}
// 获取当前模板设置
function getCurrentTemplate() {
    $db = getDB();
    $sql = "SELECT `value` FROM `system_settings` WHERE `key` = 'current_template'";
    $result = $db->query($sql);
    if ($result->rowCount() > 0) {
        $row = $result->fetch(PDO::FETCH_ASSOC);
        return $row['value'];
    }
    return 'default'; // 默认模板
}

// 更新模板设置
if (isset($_POST['submit'])) {
    $template = $_POST['template'];
    $db = getDB();
    $sql = "UPDATE `system_settings` SET `value` = :template WHERE `key` = 'current_template'";
    $stmt = $db->prepare($sql);
    $stmt->execute(['template' => $template]);
    echo "<script>layui.use('layer', function(){layer.msg('模板已更新！', {icon: 1});});window.location.href='template_manage.php';</script>";
}

// 获取所有可用模板
function getAvailableTemplates() {
    $templateDir = '../template'; // 模板文件夹路径
    $templates = array();
    
    if (is_dir($templateDir)) {
        if ($dh = opendir($templateDir)) {
            while (($file = readdir($dh)) !== false) {
                if ($file != '.' && $file != '..' && is_dir($templateDir . '/' . $file)) {
                    $templates[] = $file;
                }
            }
            closedir($dh);
        }
    }
    return $templates;
}

$currentTemplate = getCurrentTemplate();
$availableTemplates = getAvailableTemplates();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>模板管理</title>
    <link rel="stylesheet" href="assets/libs/layui/css/layui.css">
</head>
<body class="layui-bg-gray">
    <div class="layui-container" style="padding: 20px;">
        <div class="layui-card">
            <div class="layui-card-header">
                <h1 class="layui-h1">模板管理</h1>
            </div>
            <div class="layui-card-body">
                <div class="layui-form-item">
                    <label class="layui-form-label">当前模板</label>
                    <div class="layui-input-block">
                        <span class="layui-badge layui-bg-blue"><?php echo $currentTemplate; ?></span>
                    </div>
                </div>
                
                <form class="layui-form" method="post" action="">
                    <div class="layui-form-item">
                        <label class="layui-form-label">选择模板</label>
                        <div class="layui-input-block">
                            <?php foreach ($availableTemplates as $template): ?>
                                <div class="layui-col-md4" style="margin-bottom: 15px;">
                                    <div class="layui-card <?php echo ($template == $currentTemplate) ? 'layui-card layui-border-blue' : ''; ?>">
                                        <div class="layui-card-body">
                                            <input type="radio" name="template" value="<?php echo $template; ?>" 
                                                <?php echo ($template == $currentTemplate) ? 'checked' : ''; ?> 
                                                title="<?php echo $template; ?>" 
                                                class="layui-radio">
                                            <?php if ($template == $currentTemplate): ?>
                                                <span class="layui-badge layui-bg-blue layui-m-l-10">当前使用</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="layui-form-item">
                        <div class="layui-input-block">
                            <button type="submit" name="submit" class="layui-btn layui-btn-blue">保存设置</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="layui-alert layui-bg-blue layui-text" style="margin-top: 20px;">
            <i class="layui-icon layui-icon-tips"></i> 提示：更换模板后，网站的外观将随之改变，但不会影响您的核心数据。
        </div>
    </div>
    
    <script src="assets/libs/layui/layui.js"></script>
    <script>
        layui.use(['form', 'layer'], function() {
            var form = layui.form;
            var layer = layui.layer;
            
            // 表单验证
            form.verify({
                template: function(value) {
                    if (!value) {
                        return '请选择模板';
                    }
                }
            });
        });
        
        // 禁止右键点击
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });
        
        // 禁止F12键
        document.addEventListener('keydown', function(e) {
            // F12键的keyCode是123
            if (e.keyCode === 123) {
                e.preventDefault();
            }
            // 禁止Ctrl+Shift+I
            if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
                e.preventDefault();
            }
            // 禁止Ctrl+U (查看源代码)
            if (e.ctrlKey && e.keyCode === 85) {
                e.preventDefault();
            }
        });
        
        // 防止通过浏览器菜单打开开发者工具的简单防护
        // 这不能完全阻止，但可以增加难度
        window.ondevtoolschange = function(open) {
            if (open) {
                window.close(); // 如果打开了开发者工具，关闭页面
                // 或者可以使用 location.reload() 刷新页面
            }
        };
    </script>
</body>
</html>