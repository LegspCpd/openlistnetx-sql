<?php
// 启动会话
session_start();
include '../config.php';
// 检查用户是否已经登录
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in']!== true) {
    // 如果用户未登录，重定向到登录页面
    header('Location: login.php');
    exit;
}
// 初始化错误信息和成功信息
$errorMessage = "";
$successMessage = "";

// 从 Session 获取提示信息（用于重定向后显示）
if (isset($_SESSION['success_msg'])) {
    $successMessage = $_SESSION['success_msg'];
    unset($_SESSION['success_msg']);
}
if (isset($_SESSION['error_msg'])) {
    $errorMessage = $_SESSION['error_msg'];
    unset($_SESSION['error_msg']);
}

// 处理表单提交
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取提交的返佣金额
    $amount = trim($_POST['amount']);

    // 验证金额
    if (empty($amount)) {
        $errorMessage = "返佣金额不能为空";
    } elseif (!is_numeric($amount) || $amount < 0) {
        $errorMessage = "请输入有效的返佣金额";
    } else {
        // 获取解析记录返佣百分比
                $dnsCommissionPercent = trim($_POST['dns_commission_percent']);
                if (!is_numeric($dnsCommissionPercent) || $dnsCommissionPercent < 0 || $dnsCommissionPercent > 100) {
                    $errorMessage = "请输入有效的解析记录返佣百分比（0-100）";
                    return;
                }

                // 检查是否已有设置记录
                $checkSql = "SELECT COUNT(*) as count FROM commission_settings";
                $stmt = getDB()->query($checkSql);
                $result = $stmt->fetch();
                $count = $result['count'];

                if ($count > 0) {
                    // 先获取最大的id值
                    $getIdSql = "SELECT id FROM commission_settings ORDER BY id DESC LIMIT 1";
                    $stmtId = getDB()->query($getIdSql);
                    $idResult = $stmtId->fetch();
                    $maxId = $idResult['id'];
                    
                    // 更新现有设置
                    $updateSql = "UPDATE commission_settings SET amount =?, dns_commission_percent =? WHERE id =?";
                    $stmt = getDB()->prepare($updateSql);
                    $stmt->bindValue(1, $amount);
                    $stmt->bindValue(2, $dnsCommissionPercent);
                    $stmt->bindValue(3, $maxId);
                } else {
                    // 插入新设置
                    $insertSql = "INSERT INTO commission_settings (amount, dns_commission_percent) VALUES (?, ?)";
                    $stmt = getDB()->prepare($insertSql);
                    $stmt->bindValue(1, $amount);
                    $stmt->bindValue(2, $dnsCommissionPercent);
                }

        if ($stmt->execute()) {
            $successMessage = "返佣金额设置成功";
        } else {
            $errorMessage = "设置返佣金额时出错: ". getDB()->errorInfo()[2];
        }
    }
}

// 获取当前返佣设置
$currentAmount = 10.00;
$currentDnsCommissionPercent = 5.00;
$getSql = "SELECT amount, dns_commission_percent FROM commission_settings ORDER BY id DESC LIMIT 1";
$stmt = getDB()->query($getSql);
$result = $stmt->fetch();
if ($result) {
    $currentAmount = $result['amount'];
    $currentDnsCommissionPercent = $result['dns_commission_percent'];
}
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>返佣设置 - 后台管理</title>
    <link rel="shortcut icon" href="https://q2.qlogo.cn/headimg_dl?dst_uin=2269195366&spec=100" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/layui/2.8.14/css/layui.min.css">
    <style>
        body {
            margin: 0;
            padding: 20px;
            background-color: #f2f2f2;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
        }
        .form-card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .form-header {
            background: linear-gradient(135deg, #165DFF 0%, #36BFFA 100%);
            color: #fff;
            padding: 20px;
            display: flex;
            align-items: center;
        }
        .form-header-icon {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 16px;
        }
        .form-header-title {
            font-size: 18px;
            font-weight: bold;
        }
        .form-header-desc {
            font-size: 14px;
            opacity: 0.8;
            margin-top: 4px;
        }
        .form-body {
            padding: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            color: #333;
        }
        .form-input-wrapper {
            position: relative;
        }
        .form-input-icon {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }
        .form-input {
            padding-left: 36px !important;
        }
        .btn-container {
            margin-top: 30px;
        }
        .success-message {
            padding: 12px;
            background-color: #f0f9ff;
            border: 1px solid #e0f2fe;
            border-radius: 4px;
            color: #165DFF;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }
        .error-message {
            padding: 12px;
            background-color: #fef2f2;
            border: 1px solid #fee2e2;
            border-radius: 4px;
            color: #ef4444;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }
        .message-icon {
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="form-card">

            <!-- 消息提示区域和设置表单 -->
            <div class="form-body">
                <!-- 提示消息 -->
                <?php if (!empty($errorMessage)):?>
                    <div class="error-message">
                        <i class="layui-icon layui-icon-error message-icon"></i>
                        <span><?php echo $errorMessage;?></span>
                    </div>
                <?php elseif (!empty($successMessage)):?>
                    <div class="success-message">
                        <i class="layui-icon layui-icon-ok-circle message-icon"></i>
                        <span><?php echo $successMessage;?></span>
                    </div>
                <?php endif;?>

                <!-- 返佣设置表单 -->
                <form class="layui-form" method="post">
                    <div class="form-group">
                        <label class="form-label" for="amount">每单返佣金额 (元)</label>
                        <div class="form-input-wrapper">
                            <i class="layui-icon layui-icon-rmb form-input-icon"></i>
                            <input type="number" 
                                   id="amount" 
                                   name="amount" 
                                   value="<?php echo $currentAmount;?>" 
                                   step="0.01" 
                                   min="0" 
                                   class="layui-input form-input"
                                   required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="dns_commission_percent">解析记录返佣百分比 (%)</label>
                        <div class="form-input-wrapper">
                            <i class="layui-icon layui-icon-rmb form-input-icon"></i>
                            <input type="number" 
                                   id="dns_commission_percent" 
                                   name="dns_commission_percent" 
                                   value="<?php echo $currentDnsCommissionPercent;?>" 
                                   step="0.01" 
                                   min="0" 
                                   max="100" 
                                   class="layui-input form-input"
                                   required>
                        </div>
                    </div>
                    
                    <div class="btn-container">
                        <button type="submit" class="layui-btn layui-btn-normal layui-btn-fluid">
                            <i class="layui-icon layui-icon-save"></i> 保存设置
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/layui/2.8.14/layui.min.js"></script>
    <script>
        layui.use(['form'], function() {
            var form = layui.form;
            
            // 表单验证
            form.verify({
                amount: function(value) {
                    if (!value) {
                        return '返佣金额不能为空';
                    }
                    if (isNaN(value) || parseFloat(value) < 0) {
                        return '请输入有效的返佣金额';
                    }
                },
                dns_commission_percent: function(value) {
                    if (!value) {
                        return '解析记录返佣百分比不能为空';
                    }
                    if (isNaN(value) || parseFloat(value) < 0 || parseFloat(value) > 100) {
                        return '请输入有效的解析记录返佣百分比（0-100）';
                    }
                }
            });
        });
    </script>
</body>
</html>