<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// 数据库连接配置
include_once '../config.php';

// 创建数据库连接
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

// 设置字符集
$conn->set_charset("utf8mb4");

// 处理工单操作
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 处理图片上传
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "../uploads/tickets/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $target_file = $target_dir . time() . '_' . basename($_FILES["image"]["name"]);
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            $image = substr($target_file, 3); // 移除 ../
            echo json_encode(['code' => 0, 'data' => ['src' => $image], 'msg' => '上传成功']);
        } else {
            echo json_encode(['code' => 1, 'msg' => '上传失败']);
        }
        exit;
    }
    
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'reply':
                // 处理回复工单
                if (isset($_POST['ticket_id']) && isset($_POST['content'])) {
                    $ticket_id = intval($_POST['ticket_id']);
                    $content = $conn->real_escape_string($_POST['content']);
                    $image = isset($_POST['image']) ? $_POST['image'] : '';
                    
                    // 插入回复
                    $sql = "INSERT INTO ticket_replies (ticket_id, user_id, content, image, is_admin) VALUES (?, ?, ?, ?, 1)";
                    $stmt = $conn->prepare($sql);
                    $admin_user_id = 1; // 假设管理员用户ID为1
                    $stmt->bind_param("iiss", $ticket_id, $admin_user_id, $content, $image);
                    $stmt->execute();
                    $stmt->close();
                    
                    // 更新工单状态为处理中
                    $sql = "UPDATE tickets SET status = 'processing' WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $ticket_id);
                    $stmt->execute();
                    $stmt->close();
                    
                    echo json_encode(['code' => 0, 'msg' => '回复成功']);
                } else {
                    echo json_encode(['code' => 1, 'msg' => '参数错误']);
                }
                exit;
                
            case 'close':
                // 处理关闭工单
                if (isset($_POST['ticket_id'])) {
                    $ticket_id = intval($_POST['ticket_id']);
                    $sql = "UPDATE tickets SET status = 'closed' WHERE id = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $ticket_id);
                    $stmt->execute();
                    $stmt->close();
                    echo json_encode(['code' => 0, 'msg' => '工单已关闭']);
                } else {
                    echo json_encode(['code' => 1, 'msg' => '参数错误']);
                }
                exit;
        }
    }
}

// 获取工单列表
function getTickets($conn) {
    $sql = "SELECT t.*, u.username FROM tickets t LEFT JOIN user u ON t.user_id = u.id ORDER BY t.created_at DESC";
    $result = $conn->query($sql);
    $tickets = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $tickets[] = $row;
        }
    }
    return $tickets;
}

// 获取工单详情
function getTicketDetail($conn, $ticket_id) {
    $sql = "SELECT t.*, u.username FROM tickets t LEFT JOIN user u ON t.user_id = u.id WHERE t.id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $ticket_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $ticket = $result->fetch_assoc();
    $stmt->close();
    return $ticket;
}

// 获取工单回复
function getTicketReplies($conn, $ticket_id) {
    $sql = "SELECT tr.*, u.username FROM ticket_replies tr LEFT JOIN user u ON tr.user_id = u.id WHERE tr.ticket_id = ? ORDER BY tr.created_at ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $ticket_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $replies = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $replies[] = $row;
        }
    }
    $stmt->close();
    return $replies;
}

// 获取工单列表
$tickets = getTickets($conn);

// 获取工单详情（如果有ticket_id参数）
$ticket_detail = null;
$replies = [];
if (isset($_GET['ticket_id'])) {
    $ticket_id = intval($_GET['ticket_id']);
    $ticket_detail = getTicketDetail($conn, $ticket_id);
    $replies = getTicketReplies($conn, $ticket_id);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>工单管理</title>
    <link rel="stylesheet" href="assets/libs/layui/css/layui.css">
    <link rel="stylesheet" href="assets/module/admin.css">
    <style>
        .ticket-list {
            margin: 15px;
        }
        .ticket-detail {
            margin: 15px;
        }
        .reply-item {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
        }
        .reply-item.user {
            background-color: #f5f5f5;
            margin-left: 10px;
        }
        .reply-item.admin {
            background-color: #e6f7ff;
            margin-right: 10px;
        }
        .reply-content {
            margin: 10px 0;
        }
        .reply-image {
            max-width: 100%;
            max-height: 300px;
            margin: 10px 0;
            border-radius: 3px;
        }
        .reply-time {
            font-size: 12px;
            color: #999;
            text-align: right;
        }
        .layui-form-label {
            width: 80px;
        }
        .layui-input-block {
            margin-left: 100px;
        }
        /* 表格响应式设计 */
        .table-responsive {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            margin: 0 -10px;
            padding: 0 10px;
        }
        .layui-table {
            min-width: 640px;
        }
        /* 长文本截断 */
        .layui-table td {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        /* 标题列特殊处理 */
        .layui-table td:nth-child(3) {
            max-width: 200px;
        }
        /* 时间列特殊处理 */
        .layui-table td:nth-child(5) {
            max-width: 140px;
        }
        @media screen and (max-width: 768px) {
            .layui-form-label {
                width: 60px;
            }
            .layui-input-block {
                margin-left: 70px;
            }
            .ticket-list,
            .ticket-detail {
                margin: 10px;
            }
            /* 手机端表格调整 */
            .layui-table {
                font-size: 12px;
            }
            .layui-table th,
            .layui-table td {
                padding: 8px 6px;
            }
            .layui-btn-sm {
                padding: 0 10px;
                height: 24px;
                line-height: 24px;
                font-size: 12px;
            }
            /* 手机端长文本截断调整 */
            .layui-table td:nth-child(3) {
                max-width: 150px;
            }
            .layui-table td:nth-child(5) {
                max-width: 120px;
            }
        }
        @media screen and (max-width: 480px) {
            /* 更小屏幕的调整 */
            .layui-card-header h3 {
                font-size: 16px;
            }
            .layui-card-header .layui-row {
                display: block;
            }
            .layui-card-header .layui-col-xs12 {
                width: 100%;
                margin-bottom: 10px;
            }
            .layui-card-header .layui-col-xs12:last-child {
                text-align: right;
                margin-top: 5px;
            }
            .layui-card-header .layui-btn {
                display: inline-block;
                margin-right: 10px;
                margin-bottom: 5px;
                min-width: 80px;
                height: 30px;
                line-height: 30px;
                font-size: 12px;
                padding: 0 15px;
                cursor: pointer;
                z-index: 1;
                position: relative;
            }
            .layui-table {
                font-size: 11px;
            }
            .layui-table th,
            .layui-table td {
                padding: 6px 4px;
            }
            .layui-btn-sm {
                padding: 0 12px;
                height: 26px;
                line-height: 26px;
                font-size: 11px;
                min-width: 60px;
                display: inline-block;
                text-align: center;
            }
            /* 操作列特殊处理 */
            .layui-table td:last-child {
                text-align: center;
                padding: 4px;
            }
            /* 小屏幕长文本截断调整 */
            .layui-table td:nth-child(3) {
                max-width: 100px;
            }
            .layui-table td:nth-child(5) {
                max-width: 100px;
            }
        }
    </style>
</head>
<body>
    <div class="layui-fluid">
        <div class="layui-row layui-col-space15">
            <?php if (!$ticket_detail): ?>
                <!-- 工单列表 -->
                <div class="layui-col-md12">
                    <div class="layui-card">
                        <div class="layui-card-header">
                            <h3>工单列表</h3>
                        </div>
                        <div class="layui-card-body">
                            <div class="table-responsive">
                                <table class="layui-table" lay-filter="ticket-table">
                                    <thead>
                                        <tr>
                                            <th lay-data="{field: 'id', width: 60}">工单ID</th>
                                            <th lay-data="{field: 'username', width: 80}">用户</th>
                                            <th lay-data="{field: 'title'}">标题</th>
                                            <th lay-data="{field: 'status', templet: '#statusTpl', width: 80}">状态</th>
                                            <th lay-data="{field: 'created_at', width: 120}">创建时间</th>
                                            <th lay-data="{fixed: 'right', width: 100, align: 'center', toolbar: '#actionTpl'}">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($tickets as $ticket): ?>
                                            <tr>
                                                <td><?php echo $ticket['id']; ?></td>
                                                <td><?php echo $ticket['username']; ?></td>
                                                <td><?php echo $ticket['title']; ?></td>
                                                <td><?php echo $ticket['status'] == 'open' ? '待处理' : ($ticket['status'] == 'processing' ? '处理中' : '已解决'); ?></td>
                                                <td><?php echo $ticket['created_at']; ?></td>
                                                <td>
                                                    <a href="?ticket_id=<?php echo $ticket['id']; ?>" class="layui-btn layui-btn-sm">查看</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <!-- 工单详情 -->
                <div class="layui-col-md12">
                    <div class="layui-card">
                        <div class="layui-card-header">
                            <div class="layui-row">
                                <div class="layui-col-xs12 layui-col-md8">
                                    <h3>工单详情 - #<?php echo $ticket_detail['id']; ?></h3>
                                </div>
                                <div class="layui-col-xs12 layui-col-md4 text-right" style="margin-top: 10px;">
                                    <a href="tickets.php" class="layui-btn layui-btn-sm" style="display: inline-block; margin-bottom: 5px;">返回列表</a>
                                    <?php if ($ticket_detail['status'] == 'open' || $ticket_detail['status'] == 'processing'): ?>
                                        <button class="layui-btn layui-btn-sm layui-btn-danger" id="close-ticket" style="display: inline-block; margin-bottom: 5px;">关闭工单</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="layui-card-body">
                            <div class="layui-form-item">
                                <label class="layui-form-label">工单标题</label>
                                <div class="layui-input-block">
                                    <input type="text" value="<?php echo $ticket_detail['title']; ?>" readonly class="layui-input">
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">工单内容</label>
                                <div class="layui-input-block">
                                    <textarea readonly class="layui-textarea" rows="5"><?php echo $ticket_detail['content']; ?></textarea>
                                </div>
                            </div>
                            <div class="layui-form-item">
                                <label class="layui-form-label">创建时间</label>
                                <div class="layui-input-block">
                                    <input type="text" value="<?php echo $ticket_detail['created_at']; ?>" readonly class="layui-input">
                                </div>
                            </div>
                                                       
                        </div>
                    </div>
                </div>
                
                <!-- 回复记录 -->
                <div class="layui-col-md12">
                    <div class="layui-card">
                        <div class="layui-card-header">
                            <h3>回复记录</h3>
                        </div>
                        <div class="layui-card-body">
                            <div class="reply-list">
                                <!-- 工单创建内容 -->
                                <div class="reply-item user">
                                    <div class="reply-header">
                                        <span class="layui-badge">用户</span>
                                        <span><?php echo $ticket_detail['username']; ?></span>
                                    </div>
                                    <div class="reply-content">
                                        <?php echo $ticket_detail['content']; ?>
                                    </div>
                                    <div class="reply-time">
                                        <?php echo $ticket_detail['created_at']; ?>
                                    </div>
                                </div>
                                
                                <!-- 回复记录 -->
                                <?php foreach ($replies as $reply): ?>
                                    <div class="reply-item <?php echo $reply['is_admin'] ? 'admin' : 'user'; ?>">
                                        <div class="reply-header">
                                            <span class="layui-badge <?php echo $reply['is_admin'] ? 'layui-bg-blue' : ''; ?>">
                                                <?php echo $reply['is_admin'] ? '管理员' : '用户'; ?>
                                            </span>
                                            <span><?php echo $reply['username']; ?></span>
                                        </div>
                                        <div class="reply-content">
                                            <?php echo $reply['content']; ?>
                                        </div>
                                        <?php if ($reply['image']): ?>
                                            <img src="../<?php echo $reply['image']; ?>" class="reply-image" alt="回复图片">
                                        <?php endif; ?>
                                        <div class="reply-time">
                                            <?php echo $reply['created_at']; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- 回复表单 -->
                <?php if ($ticket_detail['status'] == 'open' || $ticket_detail['status'] == 'processing'): ?>
                    <div class="layui-col-md12">
                        <div class="layui-card">
                            <div class="layui-card-header">
                                <h3>回复工单</h3>
                            </div>
                            <div class="layui-card-body">
                                <form class="layui-form" id="reply-form">
                                    <input type="hidden" name="ticket_id" value="<?php echo $ticket_detail['id']; ?>">
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">回复内容</label>
                                        <div class="layui-input-block">
                                            <textarea name="content" required lay-verify="required" placeholder="请输入回复内容" class="layui-textarea" rows="5"></textarea>
                                        </div>
                                    </div>
                                    <div class="layui-form-item">
                                        <label class="layui-form-label">上传图片</label>
                                        <div class="layui-input-block">
                                            <button type="button" class="layui-btn" id="upload-image">
                                                <i class="layui-icon"></i> 上传图片
                                            </button>
                                            <input type="hidden" name="image" id="image-input">
                                            <div id="image-preview" style="margin-top: 10px;"></div>
                                        </div>
                                    </div>
                                    <div class="layui-form-item">
                                        <div class="layui-input-block">
                                            <button class="layui-btn" lay-submit lay-filter="reply-submit">提交回复</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- 状态模板 -->
    <script type="text/html" id="statusTpl">
        {{d.status == 'open' ? '<span class="layui-badge layui-bg-green">待处理</span>' : (d.status == 'processing' ? '<span class="layui-badge layui-bg-blue">处理中</span>' : '<span class="layui-badge layui-bg-gray">已解决</span>')}}
    </script>
    
    <!-- 操作模板 -->
    <script type="text/html" id="actionTpl">
        <a href="?ticket_id={{d.id}}" class="layui-btn layui-btn-sm">查看</a>
    </script>
    
    <script src="assets/libs/layui/layui.js"></script>
    <script>
        layui.use(['table', 'form', 'upload', 'layer'], function() {
            var table = layui.table;
            var form = layui.form;
            var upload = layui.upload;
            var layer = layui.layer;
            var $ = layui.jquery;
            
            // 渲染工单表格
            table.render({
                elem: '#ticket-table',
                page: true,
                limit: 10,
                limits: [10, 20, 30],
                cellMinWidth: 80
            });
            
            // 上传图片
            upload.render({
                elem: '#upload-image',
                url: 'tickets.php',
                accept: 'images',
                acceptMime: 'image/*',
                exts: 'jpg|png|gif|bmp|jpeg',
                field: 'image',
                before: function(obj) {
                    obj.preview(function(index, file, result) {
                        $('#image-preview').html('<img src="' + result + '" alt="预览" style="max-width: 200px; max-height: 200px;">');
                    });
                },
                done: function(res) {
                    if (res.code == 0) {
                        $('#image-input').val(res.data.src);
                        layer.msg('上传成功');
                    } else {
                        layer.msg('上传失败: ' + res.msg);
                    }
                },
                error: function() {
                    layer.msg('上传失败');
                }
            });
            
            // 提交回复
            form.on('submit(reply-submit)', function(data) {
                $.ajax({
                    url: 'tickets.php',
                    type: 'POST',
                    data: {
                        action: 'reply',
                        ticket_id: data.field.ticket_id,
                        content: data.field.content,
                        image: data.field.image
                    },
                    dataType: 'json',
                    success: function(res) {
                        if (res.code == 0) {
                            layer.msg(res.msg, function() {
                                location.reload();
                            });
                        } else {
                            layer.msg(res.msg);
                        }
                    },
                    error: function() {
                        layer.msg('提交失败');
                    }
                });
                return false;
            });
            
            // 关闭工单
            $(document).ready(function() {
                var closeBtn = $('#close-ticket');
                if (closeBtn.length > 0) {
                    closeBtn.click(function() {
                        layer.confirm('确定要关闭此工单吗？', function(index) {
                            $.ajax({
                                url: 'tickets.php',
                                type: 'POST',
                                data: {
                                    action: 'close',
                                    ticket_id: <?php echo $ticket_detail['id']; ?>
                                },
                                dataType: 'json',
                                success: function(res) {
                                    if (res.code == 0) {
                                        layer.msg(res.msg, function() {
                                            location.href = 'tickets.php';
                                        });
                                    } else {
                                        layer.msg(res.msg);
                                    }
                                },
                                error: function() {
                                    layer.msg('操作失败');
                                }
                            });
                            layer.close(index);
                        });
                    });
                }
            });
        });
    </script>
</body>
</html>
<?php
// 关闭数据库连接
$conn->close();
?>