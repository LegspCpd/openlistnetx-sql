<?php
// 开启会话
session_start();
include '../config.php';
// 检查用户是否已经登录
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in']!== true) {
    // 如果用户未登录，重定向到登录页面
    header('Location: login.php');
    exit;
}
// 初始化错误信息和成功信息
$errorMessage = "";
$successMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取用户输入的原密码、新密码和确认新密码
    $oldPassword = trim($_POST['old_password']);
    $newPassword = trim($_POST['new_password']);
    $confirmNewPassword = trim($_POST['confirm_new_password']);

    // 检查必填字段是否为空
    if (empty($oldPassword) || empty($newPassword) || empty($confirmNewPassword)) {
        $errorMessage = "原密码、新密码和确认新密码均为必填项，请填写完整。";
    } elseif ($newPassword!== $confirmNewPassword) {
        $errorMessage = "新密码和确认新密码不一致，请重新输入。";
    } else {
        $userId = isset($_SESSION['user_id'])? $_SESSION['user_id'] : 1;

        try {
            // 获取数据库连接
            $db = getDB();
            
            // 查询用户原密码是否正确
            $checkSql = "SELECT password FROM accounts WHERE id =? AND password =?";
            $stmt = $db->prepare($checkSql);
            $stmt->execute([$userId, $oldPassword]);
            $result = $stmt->fetch();

            if (!$result) {
                $errorMessage = "原密码错误，请重新输入。";
            } else {
                // 更新用户密码
                $updateSql = "UPDATE accounts SET password =? WHERE id =?";
                $stmt = $db->prepare($updateSql);
                
                if ($stmt->execute([$newPassword, $userId])) {
                    $successMessage = "密码修改成功，请牢记新密码。";
                } else {
                    $errorMessage = "修改密码时出错。";
                }
            }
        } catch (PDOException $e) {
            $errorMessage = "数据库错误: ". $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zh-cn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>修改密码</title>
    <link rel="shortcut icon" href="https://q2.qlogo.cn/headimg_dl?dst_uin=2517583153&spec=100" type="image/x-icon">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#165DFF',
                        neutral: {
                            100: '#F5F7FA',
                            200: '#E4E7ED',
                            300: '#C0C4CC',
                            400: '#909399',
                            500: '#606266',
                            600: '#303133',
                        }
                    },
                    fontFamily: {
                        inter: ['Inter', 'system-ui', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            .content-auto {
                content-visibility: auto;
            }
            .input-focus {
                @apply focus:border-primary focus:ring-1 focus:ring-primary/20 transition-all duration-200;
            }
            .btn-hover {
                @apply hover:bg-primary/90 transition-all duration-200;
            }
        }
    </style>
</head>
 
<body class="bg-neutral-100 min-h-screen font-inter flex items-center justify-center p-4">
    <!-- 简化卡片样式，移除冗余阴影和夸张过渡 -->
    <div class="w-full max-w-md bg-white rounded-lg shadow-sm overflow-hidden">
        <!-- 简化头部：移除渐变背景装饰、模糊圆球，改用纯色+简约图标 -->
        <div class="bg-primary p-5 text-white text-center">
            <div class="inline-flex items-center justify-center w-12 h-12 rounded-full bg-white/20 mb-3">
                <i class="fas fa-key text-xl"></i>
            </div>
            <h1 class="text-xl font-semibold">修改密码</h1>
            <p class="text-white/80 text-sm mt-1">设置新的账户密码</p>
        </div>
        
        <div class="p-5">
            <!-- 消息提示区域：简化样式，更简约清爽 -->
            <?php if (!empty($errorMessage)):?>
                <div class="mb-4 p-2 bg-red-50 border border-red-200 rounded-md text-red-600 flex items-center text-sm">
                    <i class="fas fa-exclamation-circle mr-2 text-xs"></i>
                    <span><?php echo $errorMessage;?></span>
                </div>
            <?php elseif (!empty($successMessage)):?>
                <div class="mb-4 p-2 bg-green-50 border border-green-200 rounded-md text-green-600 flex items-center text-sm">
                    <i class="fas fa-check-circle mr-2 text-xs"></i>
                    <span><?php echo $successMessage;?></span>
                </div>
            <?php endif;?>
            
            
            <form method="post" class="space-y-4">
                <div>
                    <label for="old_password" class="block text-xs font-medium text-neutral-500 mb-1">原密码</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-400 text-sm">
                            <i class="fas fa-lock"></i>
                        </span>
                
                        <input type="text" name="old_password" id="old_password" placeholder="输入原密码" required
                            class="w-full pl-10 pr-4 py-2.5 rounded-md border border-neutral-200 bg-white text-neutral-600 text-sm input-focus">
                    </div>
                </div>
                
                <div>
                    <label for="new_password" class="block text-xs font-medium text-neutral-500 mb-1">新密码</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-400 text-sm">
                            <i class="fas fa-lock"></i>
                        </span>
                        <input type="text" name="new_password" id="new_password" placeholder="输入新密码" required
                            class="w-full pl-10 pr-4 py-2.5 rounded-md border border-neutral-200 bg-white text-neutral-600 text-sm input-focus">
                    </div>
                </div>
                
                <div>
                    <label for="confirm_new_password" class="block text-xs font-medium text-neutral-500 mb-1">确认新密码</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-400 text-sm">
                            <i class="fas fa-lock"></i>
                        </span>
                        <input type="text" name="confirm_new_password" id="confirm_new_password" placeholder="确认新密码" required
                            class="w-full pl-10 pr-4 py-2.5 rounded-md border border-neutral-200 bg-white text-neutral-600 text-sm input-focus">
                    </div>
                </div>
                <button type="submit" class="w-full py-2.5 bg-primary text-white rounded-md font-medium text-sm btn-hover flex items-center justify-center">
                    提交修改
                </button>
            </form>
        </div>
    </div>
    
    <script>
        // 简化页面加载动画：轻量淡入，无多余位移，更简约
        document.addEventListener('DOMContentLoaded', () => {
            const formContainer = document.querySelector('.max-w-md');
            formContainer.classList.add('opacity-0');
            setTimeout(() => {
                formContainer.classList.remove('opacity-0');
                formContainer.classList.add('opacity-100', 'transition-opacity', 'duration-300');
            }, 100);
        });
    </script>
    
    <script type="text/javascript">
        // 禁止右键点击
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });
        
        // 禁止F12键
        document.addEventListener('keydown', function(e) {
            // F12键的keyCode是123
            if (e.keyCode === 123) {
                e.preventDefault();
            }
            // 禁止Ctrl+Shift+I
            if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
                e.preventDefault();
            }
            // 禁止Ctrl+U (查看源代码)
            if (e.ctrlKey && e.keyCode === 85) {
                e.preventDefault();
            }
        });
        
        // 防止通过浏览器菜单打开开发者工具的简单防护
        window.ondevtoolschange = function(open) {
            if (open) {
                window.close();
            }
        };
    </script>
</body>
</html>