<?php

/**
 * 阿里云API 对接类
 */
class AliyunAPI {
    private $access_key_id;
    private $access_key_secret;
    private $base_url = 'https://alidns.aliyuncs.com';
    private $version = '2015-01-09';
    
    /**
     * 构造函数
     * @param string $access_key_id AccessKey ID
     * @param string $access_key_secret AccessKey Secret
     */
    public function __construct($access_key_id, $access_key_secret) {
        $this->access_key_id = $access_key_id;
        $this->access_key_secret = $access_key_secret;
    }
    
    /**
     * 生成签名
     * @param array $params 请求参数
     * @return string 签名
     */
    private function generateSignature($params) {
        ksort($params);
        $stringToSign = 'GET&%2F&' . urlencode(http_build_query($params, '', '&', PHP_QUERY_RFC3986));
        $signature = base64_encode(hash_hmac('sha1', $stringToSign, $this->access_key_secret . '&', true));
        return $signature;
    }
    
    /**
     * 发送API请求
     * @param array $params 请求参数
     * @return array API响应
     */
    private function request($params) {
        $params['Format'] = 'JSON';
        $params['Version'] = $this->version;
        $params['AccessKeyId'] = $this->access_key_id;
        $params['SignatureMethod'] = 'HMAC-SHA1';
        $params['SignatureVersion'] = '1.0';
        $params['SignatureNonce'] = uniqid();
        $params['Timestamp'] = gmdate('Y-m-d\TH:i:s\Z');
        
        $signature = $this->generateSignature($params);
        $params['Signature'] = $signature;
        
        $url = $this->base_url . '?' . http_build_query($params);
        
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($curl);
        curl_close($curl);
        
        return json_decode($response, true);
    }
    
    /**
     * 获取所有域名
     * @return array 域名列表
     */
    public function getDomains() {
        $params = [
            'Action' => 'DescribeDomains',
            'PageSize' => 100
        ];
        
        $response = $this->request($params);
        return $response['Domains']['Domain'] ?? [];
    }
    
    /**
     * 获取特定域名的DNS记录
     * @param string $domain_name 域名
     * @return array DNS记录列表
     */
    public function getDNSRecords($domain_name) {
        $params = [
            'Action' => 'DescribeDomainRecords',
            'DomainName' => $domain_name,
            'PageSize' => 100
        ];
        
        $response = $this->request($params);
        return $response['DomainRecords']['Record'] ?? [];
    }
    
    /**
     * 添加DNS记录
     * @param string $domain_name 域名
     * @param array $record DNS记录数据
     * @return array API响应
     */
    public function addDNSRecord($domain_name, $record) {
        $params = [
            'Action' => 'AddDomainRecord',
            'DomainName' => $domain_name,
            'RR' => $record['name'],
            'Type' => $record['type'],
            'Value' => $record['content'],
            'TTL' => $record['ttl']
        ];
        
        if (isset($record['priority'])) {
            $params['Priority'] = $record['priority'];
        }
        
        return $this->request($params);
    }
    
    /**
     * 更新DNS记录
     * @param string $record_id 记录ID
     * @param array $record 更新后的DNS记录数据
     * @return array API响应
     */
    public function updateDNSRecord($record_id, $record) {
        $params = [
            'Action' => 'UpdateDomainRecord',
            'RecordId' => $record_id,
            'RR' => $record['name'],
            'Type' => $record['type'],
            'Value' => $record['content'],
            'TTL' => $record['ttl']
        ];
        
        if (isset($record['priority'])) {
            $params['Priority'] = $record['priority'];
        }
        
        return $this->request($params);
    }
    
    /**
     * 删除DNS记录
     * @param string $record_id 记录ID
     * @return array API响应
     */
    public function deleteDNSRecord($record_id) {
        $params = [
            'Action' => 'DeleteDomainRecord',
            'RecordId' => $record_id
        ];
        
        return $this->request($params);
    }
    
    /**
     * 验证API凭据是否有效
     * @return bool 是否有效
     */
    public function validateCredentials() {
        $response = $this->getDomains();
        return !empty($response);
    }
}

?>