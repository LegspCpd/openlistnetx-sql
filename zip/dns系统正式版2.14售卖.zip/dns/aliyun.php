<?php
require_once '../config.php';
require_once 'AliyunAPI.php';

// 获取消息
$message = getMessage();

// 获取当前配置
$current_config = getAliyunConfig();

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $access_key_id = $_POST['access_key_id'];
    $access_key_secret = $_POST['access_key_secret'];
    
    // 验证必填字段
    if (empty($access_key_id) || empty($access_key_secret)) {
        showMessage('AccessKeyId和AccessKeySecret不能为空', 'error');
        redirect('aliyun.php');
    }
    
    // 验证API凭据
    try {
        $aliyun_api = new AliyunAPI($access_key_id, $access_key_secret);
        $is_valid = $aliyun_api->validateCredentials();
        
        if ($is_valid) {
            // 保存配置
            saveAliyunConfig([
                'access_key_id' => $access_key_id,
                'access_key_secret' => $access_key_secret
            ]);
            
            showMessage('阿里云配置成功！', 'success');
            redirect('aliyun.php');
        } else {
            showMessage('阿里云API凭据无效，请检查后重试', 'error');
            redirect('aliyun.php');
        }
    } catch (Exception $e) {
        showMessage('配置失败: ' . $e->getMessage(), 'error');
        redirect('aliyun.php');
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>阿里云配置 - <?php echo SYSTEM_NAME; ?></title>
    <style>
        /* 全局样式重置 & 基础变量定义（简约风格核心） */
        :root {
            --primary-color: #2563eb; /* 简约主色调（纯净蓝） */
            --text-dark: #1f2937;     /* 主要文字色 */
            --text-gray: #6b7280;     /* 次要文字色 */
            --bg-light: #f9fafb;      /* 页面背景色 */
            --card-bg: #ffffff;       /* 卡片背景色 */
            --border-color: #e5e7eb;  /* 边框色 */
            --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.05); /* 轻量阴影 */
            --radius: 8px;            /* 统一圆角（简约感） */
            --transition: all 0.2s ease-in-out; /* 统一过渡 */
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background-color: var(--bg-light); /* 替换渐变，使用简约浅灰背景 */
            min-height: 100vh;
            color: var(--text-dark);
            line-height: 1.6;
            padding: 20px 0;
        }
        
        /* 容器样式 - 精简留白，提升呼吸感 */
        .container {
            max-width: 720px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* 头部样式 - 简化视觉，去除多余装饰 */
        .header {
            text-align: center;
            margin-bottom: 24px;
            padding: 24px 0;
        }
        
        .header h1 {
            color: var(--text-dark);
            font-size: 1.8rem;
            margin-bottom: 8px;
            font-weight: 600;
        }
        
        .header p {
            color: var(--text-gray);
            font-size: 0.95rem;
        }
        
        /* 消息提示样式 - 轻量简约，去除多余边框阴影 */
        .message {
            padding: 12px 16px;
            margin-bottom: 20px;
            border-radius: var(--radius);
            font-size: 0.95rem;
            animation: fadeIn 0.3s ease;
        }
        
        .message.success {
            background: #f0fdf4;
            color: #166534;
        }
        
        .message.error {
            background: #fef2f2;
            color: #9f1239;
        }
        
        /* 主要内容样式 - 精简层级 */
        .main {
            margin-bottom: 24px;
        }
        
        .main h2 {
            color: var(--text-dark);
            font-size: 1.4rem;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 600;
        }
        
        /* 表单容器样式 - 轻量卡片，简约阴影 */
        .form-container {
            background: var(--card-bg);
            padding: 28px;
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            margin-bottom: 24px;
        }
        
        /* 表单组样式 - 精简间距，提升整洁度 */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
            color: var(--text-dark);
            font-size: 0.9rem;
        }
        
        .form-group small {
            color: var(--text-gray);
            font-weight: 400;
            margin-left: 6px;
            font-size: 0.8rem;
        }
        
        /* 输入框样式 - 扁平化设计，简约清爽 */
        .form-group input {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid var(--border-color);
            border-radius: var(--radius);
            font-size: 0.95rem;
            transition: var(--transition);
            background: var(--card-bg);
            color: var(--text-dark);
        }
        
        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.1);
        }
        
        /* 按钮样式 - 扁平化，去除渐变，简约大气 */
        .form-actions {
            display: flex;
            justify-content: center;
            margin-top: 24px;
        }
        
        .btn {
            padding: 10px 28px;
            border: none;
            border-radius: var(--radius);
            font-size: 0.95rem;
            font-weight: 500;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #1d4ed8;
        }
        
        /* 信息框样式 - 与表单卡片统一风格，保持视觉一致性 */
        .info-box {
            background: var(--card-bg);
            padding: 28px;
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
        }
        
        .info-box h3 {
            color: var(--text-dark);
            font-size: 1.1rem;
            margin-bottom: 12px;
            font-weight: 600;
        }
        
        .info-box ol {
            padding-left: 20px;
        }
        
        .info-box li {
            margin-bottom: 10px;
            color: var(--text-gray);
            font-size: 0.9rem;
        }
        
        .info-box a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }
        
        .info-box a:hover {
            text-decoration: underline;
        }
        
        /* 页脚样式 - 简化，与整体风格统一 */
        .footer {
            text-align: center;
            margin-top: 32px;
            color: var(--text-gray);
            font-size: 0.85rem;
        }
        
        /* 动画效果 - 保留轻量淡入，不浮夸 */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-6px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* 响应式设计 - 精简适配，保持移动端简约 */
        @media (max-width: 480px) {
            .form-container,
            .info-box {
                padding: 20px;
            }
            
            .header h1 {
                font-size: 1.5rem;
            }
            
            .main h2 {
                font-size: 1.2rem;
            }
            
            .btn {
                padding: 9px 24px;
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- 消息提示 -->
        <?php if ($message): ?>
            <div class="message <?php echo $message['type']; ?>">
                <?php echo $message['content']; ?>
            </div>
        <?php endif; ?>
        
        <!-- 头部 -->
        <header class="header">
            <h1>阿里云 配置管理</h1>
            <p>填写并保存你的阿里云 AccessKey 信息</p>
        </header>
        
        <!-- 主要内容 -->
        <main class="main">
            <div class="form-container">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="access_key_id">AccessKeyId</label>
                        <input type="text" id="access_key_id" name="access_key_id" 
                               value="<?php echo isset($current_config['access_key_id']) ? $current_config['access_key_id'] : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="access_key_secret">AccessKeySecret</label>
                        <input type="password" id="access_key_secret" name="access_key_secret" 
                               value="<?php echo isset($current_config['access_key_secret']) ? $current_config['access_key_secret'] : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">保存配置</button>
                    </div>
                </form>
            </div>
            
            <div class="info-box">
                <h3>获取阿里云 AccessKey</h3>
                <ol>
                    <li>登录阿里云控制台: <a href="https://ram.console.aliyun.com" target="_blank">https://ram.console.aliyun.com</a></li>
                    <li>创建或管理 AccessKey: 点击左侧导航栏 → 身份管理 → 用户 → 选择用户 → 用户详情 → AccessKey 管理</li>
                    <li>注意: 请确保该 AccessKey 拥有云解析 DNS 的管理权限</li>
                </ol>
            </div>
        </main>
        
        <!-- 页脚 -->
        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> <?php echo SYSTEM_NAME; ?></p>
        </footer>
    </div>
</body>
</html>