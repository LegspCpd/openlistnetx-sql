<?php

/**
 * 腾讯云DNSPod API 对接类
 */
class DnspodAPI {
    private $secret_id;
    private $secret_key;
    private $base_url = 'https://dnspod.tencentcloudapi.com';
    private $version = '2021-03-23';
    private $region = 'ap-guangzhou';
    
    /**
     * 构造函数
     * @param string $secret_id SecretId
     * @param string $secret_key SecretKey
     */
    public function __construct($secret_id, $secret_key) {
        $this->secret_id = $secret_id;
        $this->secret_key = $secret_key;
    }
    
    /**
     * 生成签名
     * @param string $service 服务名称
     * @param string $host 主机名
     * @param string $action 操作名称
     * @param string $version API版本
     * @param array $params 请求参数
     * @param string $region 地域
     * @param string $timestamp 时间戳
     * @param string $date 日期
     * @return string 签名
     */
    private function generateSignature($service, $host, $action, $version, $params, $region, $timestamp, $date) {
        // 1. 拼接规范请求串
        $httpRequestMethod = 'POST';
        $canonicalUri = '/';
        $canonicalQueryString = '';
        $canonicalHeaders = "content-type:application/json\nhost:$host\n";
        $signedHeaders = 'content-type;host';
        $requestPayload = json_encode($params);
        $hashedRequestPayload = hash('sha256', $requestPayload);
        
        $canonicalRequest = "$httpRequestMethod\n$canonicalUri\n$canonicalQueryString\n$canonicalHeaders\n$signedHeaders\n$hashedRequestPayload";
        
        // 2. 拼接字符串A
        $algorithm = 'TC3-HMAC-SHA256';
        $credentialScope = "$date/$service/tc3_request";
        $hashedCanonicalRequest = hash('sha256', $canonicalRequest);
        $stringToSign = "$algorithm\n$timestamp\n$credentialScope\n$hashedCanonicalRequest";
        
        // 3. 计算签名
        $secretDate = hash_hmac('sha256', $date, "TC3" . $this->secret_key, true);
        $secretService = hash_hmac('sha256', $service, $secretDate, true);
        $secretSigning = hash_hmac('sha256', 'tc3_request', $secretService, true);
        $signature = hash_hmac('sha256', $stringToSign, $secretSigning);
        
        return $signature;
    }
    
    /**
     * 发送API请求
     * @param string $action 操作名称
     * @param array $params 请求参数
     * @return array API响应
     */
    private function request($action, $params) {
        $service = 'dnspod';
        $host = 'dnspod.tencentcloudapi.com';
        $timestamp = time();
        $date = gmdate('Y-m-d', $timestamp);
        
        $signature = $this->generateSignature($service, $host, $action, $this->version, $params, $this->region, $timestamp, $date);
        
        $authorization = "TC3-HMAC-SHA256 Credential=$this->secret_id/$date/$service/tc3_request, SignedHeaders=content-type;host, Signature=$signature";
        
        $headers = [
            'Authorization: ' . $authorization,
            'Content-Type: application/json',
            'Host: ' . $host,
            'X-TC-Action: ' . $action,
            'X-TC-Version: ' . $this->version,
            'X-TC-Region: ' . $this->region,
            'X-TC-Timestamp: ' . $timestamp
        ];
        
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $this->base_url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($params));
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($curl);
        curl_close($curl);
        
        $result = json_decode($response, true);
        return $result['Response'] ?? $result;
    }
    
    /**
     * 获取所有域名
     * @return array 域名列表
     * @throws Exception 当API请求失败时抛出异常
     */
    public function getDomains() {
        $params = [
            'Offset' => 0,
            'Limit' => 100
        ];
        
        $response = $this->request('DescribeDomainList', $params);
        
        if (isset($response['Error'])) {
            throw new Exception('API Error: ' . $response['Error']['Code'] . ' - ' . $response['Error']['Message']);
        }
        
        return $response['DomainList'] ?? [];
    }
    
    /**
     * 获取特定域名的DNS记录
     * @param string $domain 域名
     * @param string $domain_id 域名ID
     * @return array DNS记录列表
     */
    public function getDNSRecords($domain, $domain_id) {
        $params = [
            'Domain' => $domain,
            'Offset' => 0,
            'Limit' => 100
        ];
        
        if (!empty($domain_id)) {
            $params['DomainId'] = $domain_id;
        }
        
        $response = $this->request('DescribeRecordList', $params);
        return $response['RecordList'] ?? [];
    }
    
    /**
     * 添加DNS记录
     * @param string $domain 域名
     * @param array $record DNS记录数据
     * @return array API响应
     */
    public function addDNSRecord($domain, $record) {
        $params = [
            'Domain' => $domain,
            'SubDomain' => $record['name'],
            'RecordType' => $record['type'],
            'RecordLine' => '默认',
            'Value' => $record['content'],
            'TTL' => $record['ttl']
        ];
        
        if (isset($record['priority'])) {
            $params['MX'] = $record['priority'];
        }
        
        return $this->request('CreateRecord', $params);
    }
    
    /**
     * 更新DNS记录
     * @param string $record_id 记录ID
     * @param array $record 更新后的DNS记录数据
     * @param string $domain 域名
     * @return array API响应
     */
    public function updateDNSRecord($record_id, $record, $domain) {
        $params = [
            'RecordId' => intval($record_id),
            'Domain' => $domain,
            'SubDomain' => $record['name'],
            'RecordType' => $record['type'],
            'RecordLine' => '默认',
            'Value' => $record['content'],
            'TTL' => $record['ttl']
        ];
        
        if (isset($record['priority'])) {
            $params['MX'] = $record['priority'];
        }
        
        return $this->request('ModifyRecord', $params);
    }
    
    /**
     * 删除DNS记录
     * @param string $record_id 记录ID
     * @param string $domain 域名
     * @return array API响应
     */
    public function deleteDNSRecord($record_id, $domain) {
        $params = [
            'RecordId' => intval($record_id),
            'Domain' => $domain
        ];
        
        return $this->request('DeleteRecord', $params);
    }
    
    /**
     * 验证API凭据是否有效
     * @return bool 是否有效
     * @throws Exception 当API请求失败时抛出异常
     */
    public function validateCredentials() {
        $response = $this->getDomains();
        return !empty($response);
    }
}

?>