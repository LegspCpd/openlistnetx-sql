<?php

/**
 * Cloudflare API 对接类
 */
class CloudflareAPI {
    private $email;
    private $api_key;
    private $api_token;
    private $base_url = 'https://api.cloudflare.com/client/v4';
    
    /**
     * 构造函数
     * @param string $email Cloudflare 邮箱
     * @param string $api_key API 密钥
     * @param string $api_token API 令牌（可选）
     */
    public function __construct($email, $api_key, $api_token = null) {
        $this->email = $email;
        $this->api_key = $api_key;
        $this->api_token = $api_token;
    }
    
    /**
     * 发送API请求
     * @param string $endpoint API端点
     * @param string $method 请求方法
     * @param array $data 请求数据
     * @return array API响应
     */
    private function request($endpoint, $method = 'GET', $data = []) {
        $url = $this->base_url . $endpoint;
        $headers = [
            'Content-Type: application/json'
        ];
        
        // 添加认证头
        if ($this->api_token) {
            $headers[] = 'Authorization: Bearer ' . $this->api_token;
        } else {
            $headers[] = 'X-Auth-Email: ' . $this->email;
            $headers[] = 'X-Auth-Key: ' . $this->api_key;
        }
        
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        
        switch ($method) {
            case 'POST':
                curl_setopt($curl, CURLOPT_POST, true);
                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
                break;
            case 'PUT':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
                break;
            case 'DELETE':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
        }
        
        $response = curl_exec($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        
        $result = json_decode($response, true);
        $result['http_code'] = $http_code;
        
        return $result;
    }
    
    /**
     * 获取所有域名（Zone）
     * @return array 域名列表
     */
    public function getZones() {
        return $this->request('/zones');
    }
    
    /**
     * 获取特定域名的DNS记录
     * @param string $zone_id 域名ID
     * @return array DNS记录列表
     */
    public function getDNSRecords($zone_id) {
        return $this->request('/zones/' . $zone_id . '/dns_records');
    }
    
    /**
     * 添加DNS记录
     * @param string $zone_id 域名ID
     * @param array $record DNS记录数据
     * @return array API响应
     */
    public function addDNSRecord($zone_id, $record) {
        return $this->request('/zones/' . $zone_id . '/dns_records', 'POST', $record);
    }
    
    /**
     * 更新DNS记录
     * @param string $zone_id 域名ID
     * @param string $record_id DNS记录ID
     * @param array $record 更新后的DNS记录数据
     * @return array API响应
     */
    public function updateDNSRecord($zone_id, $record_id, $record) {
        return $this->request('/zones/' . $zone_id . '/dns_records/' . $record_id, 'PUT', $record);
    }
    
    /**
     * 删除DNS记录
     * @param string $zone_id 域名ID
     * @param string $record_id DNS记录ID
     * @return array API响应
     */
    public function deleteDNSRecord($zone_id, $record_id) {
        return $this->request('/zones/' . $zone_id . '/dns_records/' . $record_id, 'DELETE');
    }
    
    /**
     * 验证API凭据是否有效
     * @return bool 是否有效
     */
    public function validateCredentials() {
        $response = $this->getZones();
        return isset($response['success']) && $response['success'] === true;
    }
}

?>