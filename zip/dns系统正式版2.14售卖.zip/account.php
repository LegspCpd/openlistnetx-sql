<?php
// 启动会话
session_start();
// 禁用错误输出，防止破坏JSON响应
error_reporting(0);
ini_set('display_errors', 0);

include 'config.php';

// 引入PHPMailer类
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// 初始化消息变量
$errorMessage = '';
$successMessage = '';
$emailErrorMessage = '';
$emailSuccessMessage = '';
$passwordErrorMessage = '';
$passwordSuccessMessage = '';

// 检查用户是否登录
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

// 获取当前用户信息
$stmt = getDB()->prepare("SELECT email FROM user WHERE id =?");
$stmt->execute([$userId]);
$user = $stmt->fetch();
if (!$user) {
    // 用户不存在，重定向到登录页面
    header('Location: login.php');
    exit;
}
$currentEmail = $user['email'];

// 生成随机验证码
function generateVerificationCode() {
    return rand(100000, 999999);
}

// 发送验证码邮件
function sendVerificationEmail($toEmail, $code, $type = 'verify_old') {
    // 确保在函数内也禁用错误输出
    error_reporting(0);
    
    // 获取邮箱配置
    $stmt = getDB()->query("SELECT * FROM email_config LIMIT 1");
    $config = $stmt->fetch();
    if (!$config) {
        return "未配置邮箱服务器信息";
    }

    $mail = new PHPMailer(true);
    try {
        // 服务器配置
        $mail->isSMTP();
        $mail->Host       = $config['smtp_host'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $config['smtp_username'];
        $mail->Password   = $config['smtp_password'];
        $mail->SMTPSecure = $config['smtp_encryption']? $config['smtp_encryption'] : 'tls';
        $mail->Port       = $config['smtp_port'];

        // 收件人
        $mail->setFrom($config['from_email'], $config['from_name']?? '系统通知');
        $mail->addAddress($toEmail);
        
        // 邮件内容
        $mail->isHTML(true);
        if ($type === 'verify_old') {
            $mail->Subject = '邮箱更换验证';
            $mail->Body    = "您正在更换账户绑定邮箱，本次操作的验证码是：<strong>$code</strong><br>验证码有效期为10分钟，请尽快使用。";
            $mail->AltBody = "您正在更换账户绑定邮箱，本次操作的验证码是：$code，验证码有效期为10分钟，请尽快使用。";
        } else {
            $mail->Subject = '新邮箱验证';
            $mail->Body    = "您正在将此邮箱绑定到账户，验证码是：<strong>$code</strong><br>验证码有效期为10分钟，请尽快使用。";
            $mail->AltBody = "您正在将此邮箱绑定到账户，验证码是：$code，验证码有效期为10分钟，请尽快使用。";
        }

        $mail->send();
        return true;
    } catch (Exception $e) {
        return "邮件发送失败: " . $mail->ErrorInfo;
    }
}

// 处理发送验证码的AJAX请求
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    // 清除之前可能的输出
    ob_clean();
    
    $response = ['success' => false, 'message' => ''];
    
    if ($_POST['action'] == 'send_old_code') {
        // 发送原邮箱验证码
        $code = generateVerificationCode();
        $_SESSION['old_email_verify_code'] = $code;
        $_SESSION['old_email_verify_expire'] = time() + 600; // 10分钟有效期
        
        $result = sendVerificationEmail($currentEmail, $code, 'verify_old');
        if ($result === true) {
            $response['success'] = true;
            $response['message'] = "验证码已发送到原邮箱，请查收";
        } else {
            $response['message'] = $result;
        }
    } 
    elseif ($_POST['action'] == 'send_new_code') {
        // 发送新邮箱验证码
        $newEmail = trim($_POST['new_email']);
        
        if (empty($newEmail) || !filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            $response['message'] = "请输入有效的邮箱地址";
        } else {
            // 检查邮箱是否已被使用
            $stmt = getDB()->prepare("SELECT id FROM user WHERE email =?");
            $stmt->execute([$newEmail]);
            $stmt->fetch();
            
            if ($stmt->rowCount() > 0) {
                $response['message'] = "该邮箱已被注册";
            } else {
                $code = generateVerificationCode();
                $_SESSION['new_email'] = $newEmail;
                $_SESSION['new_email_verify_code'] = $code;
                $_SESSION['new_email_verify_expire'] = time() + 600; // 10分钟有效期
                
                $result = sendVerificationEmail($newEmail, $code, 'verify_new');
                if ($result === true) {
                    $response['success'] = true;
                    $response['message'] = "验证码已发送到新邮箱，请查收";
                } else {
                    $response['message'] = $result;
                }
            }
        }
    }
    
    // 设置JSON头
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// 处理邮箱更换表单提交
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['form_type']) && $_POST['form_type'] == 'email') {
    // 检查是否提交了原邮箱验证码
    if (isset($_POST['old_code']) && !empty($_POST['old_code'])) {
        $oldCode = trim($_POST['old_code']);
        
        // 验证原邮箱验证码
        if (empty($oldCode)) {
            $emailErrorMessage = "请输入原邮箱验证码";
        }
        elseif (!isset($_SESSION['old_email_verify_code']) || $oldCode != $_SESSION['old_email_verify_code']) {
            $emailErrorMessage = "原邮箱验证码不正确";
        }
        elseif (time() > $_SESSION['old_email_verify_expire']) {
            $emailErrorMessage = "原邮箱验证码已过期，请重新获取";
        }
        else {
            // 原邮箱验证通过，设置会话变量
            $_SESSION['old_email_verified'] = true;
            $emailSuccessMessage = "原邮箱验证成功，请设置新邮箱";
        }
    }
    // 处理新邮箱验证和提交
    elseif (isset($_POST['new_email']) && isset($_POST['new_code'])) {
        $newEmail = trim($_POST['new_email']);
        $newCode = trim($_POST['new_code']);
        
        // 检查是否已验证原邮箱
        if (!isset($_SESSION['old_email_verified']) || !$_SESSION['old_email_verified']) {
            $emailErrorMessage = "请先验证原邮箱";
        }
        elseif (empty($newEmail) || empty($newCode)) {
            $emailErrorMessage = "请填写所有字段";
        }
        elseif (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            $emailErrorMessage = "请输入有效的新邮箱地址";
        }
        elseif (!isset($_SESSION['new_email']) || $_SESSION['new_email'] != $newEmail) {
            $emailErrorMessage = "新邮箱地址不匹配，请重新获取验证码";
        }
        elseif (!isset($_SESSION['new_email_verify_code']) || $newCode != $_SESSION['new_email_verify_code']) {
            $emailErrorMessage = "新邮箱验证码不正确";
        }
        elseif (time() > $_SESSION['new_email_verify_expire']) {
            $emailErrorMessage = "新邮箱验证码已过期，请重新获取";
        }
        else {
            // 检查新邮箱是否已被使用
            $stmt = getDB()->prepare("SELECT id FROM user WHERE email =?");
            $stmt->execute([$newEmail]);
            $stmt->fetch();
            
            if ($stmt->rowCount() > 0) {
                $emailErrorMessage = "该邮箱已被注册";

            } else {

                // 更新邮箱
                $stmt = getDB()->prepare("UPDATE user SET email =? WHERE id =?");
                
                if ($stmt->execute([$newEmail, $userId])) {
                    $emailSuccessMessage = "邮箱更新成功，请使用新邮箱登录";
                    // 清除会话中的验证码信息
                    unset($_SESSION['old_email_verify_code'], $_SESSION['old_email_verify_expire'],
                          $_SESSION['old_email_verified'],
                          $_SESSION['new_email'], $_SESSION['new_email_verify_code'], $_SESSION['new_email_verify_expire']);
                } else {
                    $emailErrorMessage = "邮箱更新失败，请稍后重试";
                }

            }
        }
    }
}

// 处理密码修改请求
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['form_type']) && $_POST['form_type'] == 'password') {
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    
    // 验证输入
    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        $passwordErrorMessage = "所有字段均为必填项";
    } elseif ($newPassword != $confirmPassword) {
        $passwordErrorMessage = "两次输入的新密码不一致";
    } elseif (strlen($newPassword) < 6) {
        $passwordErrorMessage = "新密码长度至少为6位";
    } else {
        try {
            $db = getDB();
            
            // 验证当前密码
            $stmt = $db->prepare("SELECT password FROM user WHERE id = ?");
            $stmt->execute([$userId]);
            $result = $stmt->fetch();
            
            if ($result) {
                $hashedPassword = $result['password'];
                
                // 这里需要根据实际的密码存储方式进行验证
                // 如果密码是明文存储（不推荐）
                if ($currentPassword == $hashedPassword) {
                    // 更新密码
                    $updateStmt = $db->prepare("UPDATE user SET password = ? WHERE id = ?");
                    if ($updateStmt->execute([$newPassword, $userId])) {
                        $passwordSuccessMessage = "密码修改成功";
                    } else {
                        $passwordErrorMessage = "密码修改失败";
                    }
                } else {
                    $passwordErrorMessage = "当前密码错误";
                }
            } else {
                $passwordErrorMessage = "用户不存在";
            }
        } catch (PDOException $e) {
            $passwordErrorMessage = "数据库错误: " . $e->getMessage();
        }
    }
}

?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>账户设置</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/layui/2.9.10/css/layui.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
            background-color: #f5f7fa;
        }
        .container {
            max-width: 600px;
            width: 100%;
            padding: 30px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            box-sizing: border-box;
        }
        .layui-tab-title {
            margin-bottom: 20px;
        }
        .layui-tab-title li {
            font-size: 16px;
        }
        .layui-tab-title .layui-this {
            font-weight: 600;
        }
    </style>
</head>
 
<body>
    <div class="container">
        <div style="text-align: center; margin-bottom: 30px;">
            <i class="layui-icon layui-icon-setting" style="font-size: 48px; color: #1E9FFF; margin-bottom: 15px;"></i>
            <h1 style="font-size: 24px; color: #333; font-weight: 600;">账户设置</h1>
            <p style="font-size: 14px; color: #666; margin-top: 10px;">管理您的账户信息</p>
        </div>
        
        <div class="layui-tab" lay-filter="accountTabs">
            <ul class="layui-tab-title" style="display: flex;">
                <li class="layui-this" lay-id="email" style="flex: 1; text-align: center;">更换邮箱</li>
                <li lay-id="password" style="flex: 1; text-align: center;">修改密码</li>
            </ul>
            <div class="layui-tab-content">
                <!-- 更换邮箱标签内容 -->
                <div class="layui-tab-item layui-show">
                    <?php if (!empty($emailErrorMessage)): ?>
                        <div class="layui-alert layui-bg-red" style="margin-bottom: 20px;" close="true">
                            <i class="layui-icon layui-icon-error"></i> <?php echo $emailErrorMessage; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($emailSuccessMessage)): ?>
                        <div class="layui-alert layui-bg-green" style="margin-bottom: 20px;" close="true">
                            <i class="layui-icon layui-icon-success"></i> <?php echo $emailSuccessMessage; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (!isset($_SESSION['old_email_verified']) || !$_SESSION['old_email_verified']): ?>
                    <!-- 原邮箱验证表单 -->
                    <form class="layui-form" method="post" id="verifyOldEmailForm">
                        <input type="hidden" name="form_type" value="email">
                        <!-- 原邮箱验证 -->
                        <div class="layui-form-item">
                            <div style="width: 100%;">
                                <input type="email" id="old_email" value="<?php echo htmlspecialchars($currentEmail); ?>" readonly 
                                       class="layui-input layui-disabled" lay-verify="email" style="width: 100%;">
                            </div>
                        </div>
                        
                        <div class="layui-form-item">
                            <div style="width: 100%;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <input type="text" id="old_code" name="old_code" placeholder="请输入原邮箱收到的验证码" required 
                                           class="layui-input" lay-verify="required" style="flex: 1;">
                                    <button type="button" id="sendOldCodeBtn" class="layui-btn layui-btn-normal">发送验证码</button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="layui-form-item">
                            <div style="width: 100%;">
                                <button type="submit" class="layui-btn layui-btn-fluid layui-btn-primary">验证原邮箱</button>
                            </div>
                        </div>
                    </form>
                    <?php else: ?>
                    <!-- 新邮箱设置表单 -->
                    <form class="layui-form" method="post" id="setNewEmailForm">
                        <input type="hidden" name="form_type" value="email">
                        <!-- 新邮箱设置 -->
                        <div class="layui-form-item">
                            <div style="width: 100%;">
                                <input type="email" id="new_email" name="new_email" placeholder="请输入新邮箱地址" required 
                                       class="layui-input" lay-verify="required|email" style="width: 100%;">
                            </div>
                        </div>
                        
                        <div class="layui-form-item">
                            <div style="width: 100%;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <input type="text" id="new_code" name="new_code" placeholder="请输入新邮箱收到的验证码" required 
                                           class="layui-input" lay-verify="required" style="flex: 1;">
                                    <button type="button" id="sendNewCodeBtn" class="layui-btn layui-btn-normal" disabled>发送验证码</button>
                                </div>
                            </div>
                        </div>
                        
                        <div class="layui-form-item">
                            <div style="width: 100%;">
                                <button type="submit" class="layui-btn layui-btn-fluid layui-btn-primary">确认更换邮箱</button>
                            </div>
                        </div>
                    </form>
                    <?php endif; ?>
                </div>
                
                <!-- 修改密码标签内容 -->
                <div class="layui-tab-item">
                    <form class="layui-form" method="post">
                        <input type="hidden" name="form_type" value="password">
                        <div class="layui-form-item">
                            <div class="layui-input-inline" style="width: 100%; max-width: 300px; margin-left: 50%; transform: translateX(-50%);">
                                <input type="text" name="current_password" id="current_password" lay-verify="required" placeholder="请输入当前密码" class="layui-input">
                            </div>
                        </div>
                        
                        <div class="layui-form-item">
                            <div class="layui-input-inline" style="width: 100%; max-width: 300px; margin-left: 50%; transform: translateX(-50%);">
                                <input type="text" name="new_password" id="new_password" lay-verify="required|min:6" placeholder="请输入新密码（至少6位）" class="layui-input">
                            </div>
                        </div>
                        
                        <div class="layui-form-item">
                            <div class="layui-input-inline" style="width: 100%; max-width: 300px; margin-left: 50%; transform: translateX(-50%);">
                                <input type="text" name="confirm_password" id="confirm_password" lay-verify="required|confirm:new_password" placeholder="请再次输入新密码" class="layui-input">
                            </div>
                        </div>
                        
                        <div class="layui-form-item">
                            <div style="text-align: center; margin-top: 20px;">
                                <button class="layui-btn" lay-submit lay-filter="changePassword">修改密码</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/layui/2.9.10/layui.js"></script>
    <script>
        layui.use(['form', 'layer', 'element'], function() {
            var form = layui.form;
            var layer = layui.layer;
            var element = layui.element;
            
            // 获取元素
            const sendOldCodeBtn = document.getElementById('sendOldCodeBtn');
            const sendNewCodeBtn = document.getElementById('sendNewCodeBtn');
            const newEmailInput = document.getElementById('new_email');
            
            // 如果存在新邮箱输入框，添加验证事件
            if (newEmailInput) {
                newEmailInput.addEventListener('input', function() {
                    const email = this.value.trim();
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    
                    if (sendNewCodeBtn) {
                        sendNewCodeBtn.disabled =!emailRegex.test(email);
                    }
                });
            }
            
            // 如果存在原邮箱验证码按钮，添加点击事件
            if (sendOldCodeBtn) {
                sendOldCodeBtn.addEventListener('click', function() {
                    const btn = this;
                    startCountdown(btn, 60);
                    
                    const formData = new FormData();
                    formData.append('action', 'send_old_code');
                    
                    fetch(window.location.href, {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'Accept': 'application/json'
                        }
                    })
                   .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                   .then(data => {
                        if (data.success) {
                            layer.msg(data.message, {icon: 1, time: 3000});
                        } else {
                            layer.msg(data.message, {icon: 5, time: 3000});
                            resetButton(btn, '发送验证码');
                        }
                    })
                   .catch(error => {
                        layer.msg('网络错误，请稍后重试', {icon: 5, time: 3000});
                        resetButton(btn, '发送验证码');
                    });
                });
            }
            
            // 如果存在新邮箱验证码按钮，添加点击事件
            if (sendNewCodeBtn && newEmailInput) {
                sendNewCodeBtn.addEventListener('click', function() {
                    const btn = this;
                    const newEmail = newEmailInput.value.trim();
                    
                    startCountdown(btn, 60);
                    
                    const formData = new FormData();
                    formData.append('action', 'send_new_code');
                    formData.append('new_email', newEmail);
                    
                    fetch(window.location.href, {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'Accept': 'application/json'
                        }
                    })
                   .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                   .then(data => {
                        if (data.success) {
                            layer.msg(data.message, {icon: 1, time: 3000});
                        } else {
                            layer.msg(data.message, {icon: 5, time: 3000});
                            resetButton(btn, '发送验证码');
                        }
                    })
                   .catch(error => {
                        layer.msg('网络错误，请稍后重试', {icon: 5, time: 3000});
                        resetButton(btn, '发送验证码');
                    });
                });
            }
            
            // 倒计时函数
            function startCountdown(button, seconds) {
                let count = seconds;
                button.disabled = true;
                button.textContent = `重新发送(${count}s)`;
                
                const countdown = setInterval(() => {
                    count--;
                    button.textContent = `重新发送(${count}s)`;
                    
                    if (count <= 0) {
                        clearInterval(countdown);
                        button.disabled = false;
                        button.textContent = '发送验证码';
                    }
                }, 1000);
            }
            
            // 重置按钮状态
            function resetButton(button, text) {
                button.disabled = false;
                button.textContent = text;
            }
            
            // 自定义验证规则
            form.verify({
                confirm: function(value, item) {
                    var newPassword = document.getElementById('new_password').value;
                    if (value !== newPassword) {
                        return '两次输入的密码不一致';
                    }
                }
            });
            
            // 显示密码错误信息
            <?php if (!empty($passwordErrorMessage)): ?>
            layer.msg('<?php echo $passwordErrorMessage;?>', {
                icon: 5,
                time: 3000,
                anim: 6
            });
            <?php endif;?>
            
            // 显示密码成功信息
            <?php if (!empty($passwordSuccessMessage)): ?>
            layer.msg('<?php echo $passwordSuccessMessage;?>', {
                icon: 6,
                time: 3000
            });
            <?php endif;?>
            
            // 监听标签切换
            element.on('tab(accountTabs)', function(data) {
                // 可以在这里添加标签切换时的逻辑
            });
            
            // 禁止右键点击
            document.addEventListener('contextmenu', function(e) {
                e.preventDefault();
            });
            
            // 禁止F12键和相关快捷键
            document.addEventListener('keydown', function(e) {
                // 禁止F12
                if (e.keyCode === 123) {
                    e.preventDefault();
                }
                // 禁止Ctrl+Shift+I
                if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
                    e.preventDefault();
                }
                // 禁止Ctrl+U (查看源代码)
                if (e.ctrlKey && e.keyCode === 85) {
                    e.preventDefault();
                }
            });
        });
    </script>
     <script type="text/javascript">
        // 禁止右键点击
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });
        
        // 禁止F12键
        document.addEventListener('keydown', function(e) {
            // F12键的keyCode是123
            if (e.keyCode === 123) {
                e.preventDefault();
            }
            // 禁止Ctrl+Shift+I
            if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
                e.preventDefault();
            }
            // 禁止Ctrl+U (查看源代码)
            if (e.ctrlKey && e.keyCode === 85) {
                e.preventDefault();
            }
        });
        
        // 防止通过浏览器菜单打开开发者工具的简单防护
        // 这不能完全阻止，但可以增加难度
        window.ondevtoolschange = function(open) {
            if (open) {
                window.close(); // 如果打开了开发者工具，关闭页面
                // 或者可以使用 location.reload() 刷新页面
            }
        };
    </script>
</body>
</html>