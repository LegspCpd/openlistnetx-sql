<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>商户配置管理</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#165DFF',
                        secondary: '#0FC6C2',
                        success: '#00B42A',
                        warning: '#FF7D00',
                        danger: '#F53F3F',
                        dark: '#1D2129',
                        light: '#F2F3F5'
                    },
                    fontFamily: {
                        inter: ['Inter', 'system-ui', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            .content-auto {
                content-visibility: auto;
            }
            .shadow-soft {
                box-shadow: 0 2px 15px rgba(0, 0, 0, 0.05);
            }
            .bg-gradient-primary {
                background: linear-gradient(135deg, #165DFF 0%, #0FC6C2 100%);
            }
            .transition-all-300 {
                transition: all 0.3s ease;
            }
        }
    </style>
</head>
<body class="bg-gray-50 font-inter text-dark min-h-screen flex flex-col">
  
    <!-- 主内容区 -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <!-- 页面标题 -->
        <div class="mb-8">
            <h2 class="text-[clamp(1.5rem,3vw,2rem)] font-bold text-dark mb-2">商户配置</h2>
            <p class="text-gray-500">管理您的商户账户信息和API设置</p>
        </div>

        <!-- 配置卡片 -->
        <div class="max-w-3xl mx-auto bg-white rounded-xl shadow-soft p-6 md:p-8 transition-all-300 hover:shadow-lg">
            <!-- 表单 -->
            <?php
            // 引入配置文件
            require_once 'config.php';
            ?>
            <form id="config-form" class="space-y-6">
                  <!-- API URL -->
                <div class="space-y-2">
                    <label for="api_url" class="block text-sm font-medium text-gray-700">支付API</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                            <i class="fa fa-link"></i>
                        </span>
                        <input type="url" id="api_url" name="api_url" 
                               class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/30 focus:border-primary outline-none transition-all-300"
                               value="<?php echo $config['api_url']; ?>" placeholder="支付接口地址/submit.php">
                    </div>
                </div>


                <!-- 商户ID -->
                <div class="space-y-2">
                    <label for="pid" class="block text-sm font-medium text-gray-700">商户ID</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                            <i class="fa fa-id-card"></i>
                        </span>
                        <input type="number" id="pid" name="pid" 
                               class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/30 focus:border-primary outline-none transition-all-300"
                               value="<?php echo $config['pid']; ?>" placeholder="输入商户ID">
                    </div>
                </div>

                <!-- 商户密钥 -->
                <div class="space-y-2">
                    <div class="flex justify-between items-center">
                        <label for="key" class="block text-sm font-medium text-gray-700">商户密钥</label>
                        <button type="button" id="toggle-key" class="text-sm text-primary hover:text-primary/80 transition-all-300">
                            <i class="fa fa-eye-slash"></i> 显示
                        </button>
                    </div>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-500">
                            <i class="fa fa-key"></i>
                        </span>
                        <input type="password" id="key" name="key" 
                               class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary/30 focus:border-primary outline-none transition-all-300"
                               value="<?php echo $config['key']; ?>" placeholder="输入商户密钥">
                    </div>
                </div>

               <!-- 微信支付开关 -->
<div class="space-y-2">
    <div class="flex items-center">
        <div class="flex items-center justify-center w-10 h-10 rounded-lg bg-[#07C160]/10 text-[#07C160] mr-3">
            <i class="fa-brands fa-weixin text-lg"></i>
        </div>
        <label for="wxpay_enabled" class="flex-1 text-sm font-medium text-gray-700">微信支付开关</label>
        <div class="ml-auto">
            <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" id="wxpay_enabled" name="wxpay_enabled" 
                       <?php echo $config['wxpay_enabled'] ? 'checked' : ''; ?>
                       class="sr-only peer">
                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#1677FF]"></div>
            </label>
        </div>
    </div>
</div>

<!-- 支付宝支付开关 -->
<div class="space-y-2">
    <div class="flex items-center">
        <div class="flex items-center justify-center w-10 h-10 rounded-lg bg-[#1677FF]/10 text-[#1677FF] mr-3">
            <i class="fa-brands fa-alipay text-lg"></i>
        </div>
        <label for="alipay_enabled" class="flex-1 text-sm font-medium text-gray-700">支付宝支付开关</label>
        <div class="ml-auto">
            <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" id="alipay_enabled" name="alipay_enabled" 
                       <?php echo $config['alipay_enabled'] ? 'checked' : ''; ?>
                       class="sr-only peer">
                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#1677FF]"></div>
            </label>
        </div>
    </div>
</div>    

                <!-- 以下是隐藏通知URL和返回URL的部分 -->
                <input type="hidden" id="notify_url" name="notify_url" value="<?php echo $config['notify_url']; ?>">
                <input type="hidden" id="return_url" name="return_url" value="<?php echo $config['return_url']; ?>">

                <!-- 表单操作按钮 -->
                <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-4 sm:space-y-0 pt-4 border-t border-gray-100">
                    <div class="text-sm text-gray-500">
                        <i class="fa fa-info-circle mr-1"></i> 修改配置后请点击"保存更改"
                    </div>
                    <div class="flex space-x-3">
                        <button type="button" id="reset-btn" class="px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 bg-white hover:bg-gray-50 transition-all-300">
                            <i class="fa fa-refresh mr-1"></i> 重置
                        </button>
                        <button type="submit" id="save-btn" class="px-4 py-2.5 bg-primary text-white rounded-lg hover:bg-primary/90 transition-all-300 shadow-md hover:shadow-lg flex items-center justify-center">
                            <i class="fa fa-save mr-1"></i> 保存更改
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- 配置状态卡片 -->
        <div class="max-w-3xl mx-auto mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white rounded-xl shadow-soft p-6 transition-all-300 hover:shadow-lg">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-sm font-medium text-gray-500">配置状态</h3>
                    <span id="config-status" class="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-success">
                        <i class="fa fa-check-circle mr-1"></i> 已保存
                    </span>
                </div>
                <p class="text-sm text-gray-600">上次更新: <span id="last-updated">刚刚</span></p>
            </div>
            <div class="bg-white rounded-xl shadow-soft p-6 transition-all-300 hover:shadow-lg">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-sm font-medium text-gray-500">API 状态</h3>
                    <span id="api-status" class="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-warning">
                        <i class="fa fa-refresh fa-spin mr-1"></i> 检查中
                    </span>
                </div>
                <p class="text-sm text-gray-600">响应时间: <span id="response-time">-</span></p>
            </div>
            <div class="bg-white rounded-xl shadow-soft p-6 transition-all-300 hover:shadow-lg">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-sm font-medium text-gray-500">密钥强度</h3>
                    <span id="key-strength" class="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-primary">
                        <i class="fa fa-shield mr-1"></i> 强
                    </span>
                </div>
                <div class="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div id="strength-bar" class="bg-primary h-2 rounded-full" style="width: 85%"></div>
                </div>
            </div>
        </div>
    </main>

    <!-- 页脚 -->
    <footer class="bg-white border-t border-gray-200 py-6">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="text-sm text-gray-500 mb-4 md:mb-0">
                    &copy; 2025 小年系统后台管理. 保留所有权利.
                </div>
                
            </div>
        </div>
    </footer>

    <!-- 成功提示模态框 -->
    <div id="success-modal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 opacity-0 pointer-events-none transition-opacity duration-300">
        <div class="bg-white rounded-xl p-6 max-w-md w-full mx-4 transform scale-95 transition-transform duration-300">
            <div class="text-center">
                <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-success mb-4">
                    <i class="fa fa-check text-2xl"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-900 mb-2">保存成功</h3>
                <p class="text-gray-500 mb-6">您的配置已成功更新</p>
                <button id="close-modal" class="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-all-300 w-full">
                    确定
                </button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 获取表单和相关元素
            const configForm = document.getElementById('config-form');
            const toggleKeyBtn = document.getElementById('toggle-key');
            const keyInput = document.getElementById('key');
            const resetBtn = document.getElementById('reset-btn');
            const saveBtn = document.getElementById('save-btn');
            const successModal = document.getElementById('success-modal');
            const closeModalBtn = document.getElementById('close-modal');
            const configStatus = document.getElementById('config-status');
            const lastUpdated = document.getElementById('last-updated');
            const apiStatus = document.getElementById('api-status');
            const responseTime = document.getElementById('response-time');
            
            // 初始配置数据
            const initialConfig = {
                pid: document.getElementById('pid').value,
                key: document.getElementById('key').value,
                api_url: document.getElementById('api_url').value,
                notify_url: document.getElementById('notify_url').value,
                return_url: document.getElementById('return_url').value,
                wxpay_enabled: document.getElementById('wxpay_enabled').checked,
                alipay_enabled: document.getElementById('alipay_enabled').checked
            };
            
            // 切换密钥可见性
            toggleKeyBtn.addEventListener('click', function() {
                const isPassword = keyInput.type === 'password';
                keyInput.type = isPassword ? 'text' : 'password';
                toggleKeyBtn.innerHTML = isPassword ? 
                    '<i class="fa fa-eye"></i> 隐藏' : 
                    '<i class="fa fa-eye-slash"></i> 显示';
            });
            
            // 重置表单
            resetBtn.addEventListener('click', function() {
                // 恢复初始值
                for (const [key, value] of Object.entries(initialConfig)) {
                    if (key === 'wxpay_enabled' || key === 'alipay_enabled') {
                        document.getElementById(key).checked = value;
                    } else {
                        document.getElementById(key).value = value;
                    }
                }
                
                // 显示重置动画效果
                configForm.classList.add('animate-pulse');
                setTimeout(() => {
                    configForm.classList.remove('animate-pulse');
                }, 500);
                
                // 更新状态
                updateConfigStatus('已重置', 'success');
            });
            
            // 保存表单
            configForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // 收集表单数据
                const formData = {
                    pid: document.getElementById('pid').value,
                    key: document.getElementById('key').value,
                    api_url: document.getElementById('api_url').value,
                    notify_url: document.getElementById('notify_url').value,
                    return_url: document.getElementById('return_url').value,
                    wxpay_enabled: document.getElementById('wxpay_enabled').checked,
                    alipay_enabled: document.getElementById('alipay_enabled').checked
                };
                
                // 模拟API调用保存配置
                saveBtn.disabled = true;
                saveBtn.innerHTML = '<i class="fa fa-spinner fa-spin mr-1"></i> 保存中...';
                
                // 使用AJAX发送数据到PHP脚本
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'save_config.php', true);
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            // 更新初始配置为新值
                            Object.assign(initialConfig, formData);
                            
                            // 更新状态
                            updateConfigStatus('已保存', 'success');
                            
                            // 显示成功模态框
                            showSuccessModal();
                            
                            // 恢复按钮状态
                            saveBtn.disabled = false;
                            saveBtn.innerHTML = '<i class="fa fa-save mr-1"></i> 保存更改';
                            
                            // 检查API状态
                            checkApiStatus(formData.api_url);
                        } else {
                            updateConfigStatus('保存失败', 'danger');
                            saveBtn.disabled = false;
                            saveBtn.innerHTML = '<i class="fa fa-save mr-1"></i> 保存更改';
                        }
                    }
                };
                xhr.send(JSON.stringify(formData));
            });
            
            // 关闭成功模态框
            closeModalBtn.addEventListener('click', function() {
                hideSuccessModal();
            });
            
            // 显示成功模态框
            function showSuccessModal() {
                successModal.classList.remove('opacity-0', 'pointer-events-none');
                successModal.querySelector('div').classList.remove('scale-95');
                successModal.querySelector('div').classList.add('scale-100');
            }
            
            // 隐藏成功模态框
            function hideSuccessModal() {
                successModal.classList.add('opacity-0', 'pointer-events-none');
                successModal.querySelector('div').classList.remove('scale-100');
                successModal.querySelector('div').classList.add('scale-95');
            }
            
            // 更新配置状态
            function updateConfigStatus(text, status) {
                // 更新状态文本和颜色
                configStatus.innerHTML = status === 'success' ? 
                    '<i class="fa fa-check-circle mr-1"></i> ' + text : 
                    '<i class="fa fa-exclamation-circle mr-1"></i> ' + text;
                
                configStatus.className = status === 'success' ? 
                    'px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-success' : 
                    'px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-danger';
                
                // 更新最后更新时间
                const now = new Date();
                const timeString = now.toLocaleTimeString();
                lastUpdated.textContent = timeString;
                
                // 添加状态变化动画
                configStatus.classList.add('animate-pulse');
                setTimeout(() => {
                    configStatus.classList.remove('animate-pulse');
                }, 1000);
            }
            
            // 检查API状态
            function checkApiStatus(apiUrl) {
                // 显示检查中状态
                apiStatus.innerHTML = '<i class="fa fa-refresh fa-spin mr-1"></i> 检查中';
                apiStatus.className = 'px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-warning';
                responseTime.textContent = '-';
                
                // 创建一个简单的HEAD请求来检查URL是否可达
                const start = performance.now();
                fetch(apiUrl, { method: 'HEAD', mode: 'no-cors', cache: 'no-cache' })
                    .then(response => {
                        const end = performance.now();
                        const time = Math.round(end - start);
                        
                        responseTime.textContent = time + 'ms';
                        
                        if (response.ok) {
                            apiStatus.innerHTML = '<i class="fa fa-check-circle mr-1"></i> 正常';
                            apiStatus.className = 'px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-success';
                        } else {
                            apiStatus.innerHTML = '<i class="fa fa-exclamation-circle mr-1"></i> 错误';
                            apiStatus.className = 'px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-danger';
                        }
                    })
                    .catch(error => {
                        responseTime.textContent = '-';
                        apiStatus.innerHTML = '<i class="fa fa-exclamation-circle mr-1"></i> 无法连接';
                        apiStatus.className = 'px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-danger';
                    });
            }
            
            // 添加输入字段的动画效果
            const inputs = document.querySelectorAll('input');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.classList.add('scale-[1.01]');
                    this.parentElement.style.transition = 'all 0.2s ease';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.classList.remove('scale-[1.01]');
                });
            });
            
            // 初始检查API状态
            checkApiStatus(initialConfig.api_url);
        });
    </script>
      <!-- 禁止F12和右键点击的脚本 -->
    <script type="text/javascript">
        // 禁止右键点击
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });
        
        // 禁止F12键
        document.addEventListener('keydown', function(e) {
            // F12键的keyCode是123
            if (e.keyCode === 123) {
                e.preventDefault();
            }
            // 禁止Ctrl+Shift+I
            if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
                e.preventDefault();
            }
            // 禁止Ctrl+U (查看源代码)
            if (e.ctrlKey && e.keyCode === 85) {
                e.preventDefault();
            }
        });
        
        // 防止通过浏览器菜单打开开发者工具的简单防护
        // 这不能完全阻止，但可以增加难度
        window.ondevtoolschange = function(open) {
            if (open) {
                window.close(); // 如果打开了开发者工具，关闭页面
                // 或者可以使用 location.reload() 刷新页面
            }
        };
    </script>
</body>
</html>