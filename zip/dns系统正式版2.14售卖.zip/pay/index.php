<?php
// 引入配置文件
require_once 'config.php';
require_once '../config.php'; // 引入主配置文件获取数据库连接
// 自动获取当前域名和协议
$home_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . "/";

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start();
    
    // 检查用户是否已登录
    if (!isset($_SESSION['user_id'])) {
        die('请先登录后再进行充值');
    }
    
    $user_id = $_SESSION['user_id'];
    $out_trade_no = createOrderNo();
    $time = time();
    $data = [
        'pid'          => $config['pid'],
        'type'         => $_POST['type'],
        'out_trade_no' => $out_trade_no,
        'notify_url'   => $config['notify_url'],
        'return_url'   => $config['return_url'],
        'name'         => substr($_POST['name'], 0, 127),
        'money'        => number_format($_POST['amount'], 2, '.', ''),
        'timestamp'    => $time
    ];
    
    // 获取数据库连接
    $db = getDB();
    
    // 插入订单列表
    $insertSql = "INSERT INTO order_list (user_id, out_trade_no, create_time) VALUES (?, ?, ?)";
    $stmt = $db->prepare($insertSql);
    $stmt->execute([$user_id, $out_trade_no, $time]);
    
    // 插入充值记录（初始状态为pending）
    $paymentMethod = $_POST['type'] == 'wxpay' ? '微信支付' : '支付宝';
    $recordSql = "INSERT INTO recharge_records (user_id, out_trade_no, amount, payment_method, status, create_time) 
                  VALUES (?, ?, ?, ?, 'pending', NOW())";
    $stmtRecord = $db->prepare($recordSql);
    $stmtRecord->execute([$user_id, $out_trade_no, $data['money'], $paymentMethod]);
    
    // 修改后的签名生成代码
    ksort($data);
    $sign_str = urldecode(http_build_query($data)) . $config['key'];
    $data['sign'] = md5($sign_str);
}

// 生成订单号
function createOrderNo() {
    return date('YmdHis') . substr(implode('', array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>在线充值</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#165DFF',
                        secondary: '#4080FF',
                        accent: '#0E42D2',
                        neutral: {
                            100: '#F5F7FA',
                            200: '#E5E6EB',
                            300: '#C9CDD4',
                            400: '#86909C',
                            500: '#4E5969',
                            600: '#272E3B',
                            700: '#1D2129',
                        }
                    },
                    fontFamily: {
                        inter: ['Inter', 'system-ui', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            .content-auto {
                content-visibility: auto;
            }
            .card-shadow {
                box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.1);
            }
            .btn-hover {
                transition: all 0.3s ease;
            }
            .btn-hover:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 25px -5px rgba(22, 93, 255, 0.3);
            }
            .input-focus {
                transition: all 0.2s ease;
            }
            .input-focus:focus {
                border-color: #165DFF;
                box-shadow: 0 0 0 3px rgba(22, 93, 255, 0.2);
            }
        }
    </style>
</head>
<body class="bg-neutral-100 min-h-screen font-inter text-neutral-700">
    <div class="container mx-auto px-4 py-8 max-w-xl">
        <div class="flex justify-center mb-4">
            <div class="bg-white rounded-xl card-shadow w-full max-w-sm overflow-hidden">
                <!-- 支付头部 -->
                <div class="bg-gradient-to-r from-primary to-secondary text-white p-6">
                    <div class="flex items-center justify-between mb-3">
                        <div class="text-[clamp(1.25rem,3vw,1.5rem)] font-bold">在线充值</div>
                        <div class="bg-white/20 px-2 py-0.5 rounded-full text-xs backdrop-blur-sm">
                            <i class="fa fa-shield mr-1"></i> 安全支付
                        </div>
                    </div>
                    <p class="text-white/80 text-sm">安全便捷的支付体验</p>
                </div>
                
                <!-- 支付表单 -->
                <div class="p-4 md:p-6">
                    <?php if (!isset($data)) : ?>
                    <form method="post" id="paymentForm">
                        <div class="space-y-4">
                            <!-- 支付金额 -->
                            <div>
                                <label class="block text-xs font-medium text-neutral-500 mb-1">支付金额（元）</label>
                                <div class="relative">
                                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-neutral-500">
                                        <i class="fa fa-cny"></i>
                                    </span>
                                    <input type="number" class="w-full px-8 py-3 rounded-lg border border-neutral-200 input-focus text-[clamp(1rem,2vw,1.25rem)] font-medium" name="amount" min="0.01" step="0.01" value="1.00" required>
                                </div>
                            </div>
                            
                            <!-- 支付留言 -->
                            <div>
                                <label class="block text-xs font-medium text-neutral-500 mb-1">订单备注</label>
                                <input type="text" class="w-full px-4 py-3 rounded-lg border border-neutral-200 input-focus" name="name" value="小年DNS系统" required readonly>
                            </div>
                            
                            <!-- 支付方式 -->
                            <div>
                                <label class="block text-xs font-medium text-neutral-500 mb-1">选择支付方式</label>
                                <div class="relative">
                                    <select name="type" class="w-full px-4 py-3 rounded-lg border border-neutral-200 input-focus appearance-none bg-white">
                                        <?php if ($config['wxpay_enabled']) : ?>
                                        <option value="wxpay">
                                            <i class="fa-brands fa-weixin mr-2"></i>微信支付
                                        </option>
                                        <?php endif; ?>
                                        
                                        <?php if ($config['alipay_enabled']) : ?>
                                        <option value="alipay">
                                            <i class="fa-brands fa-alipay mr-2"></i>支付宝支付
                                        </option>
                                        <?php endif; ?>
                                    </select>
                                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-neutral-500">
                                        <i class="fa fa-chevron-down text-xs"></i>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- 立即支付按钮 -->
                            <div class="pt-2">
                                <button type="submit" class="w-full flex items-center justify-center px-6 py-3 rounded-lg bg-primary text-white text-base font-medium btn-hover">
                                    <i class="fa fa-credit-card mr-2"></i>
                                    立即支付
                                </button>
                            </div>
                            
                            <!-- 安全提示 -->
                            <div class="pt-2">
                                <div class="flex items-center text-neutral-400 text-xs">
                                    <i class="fa fa-lock mr-2"></i>
                                    <span>所有交易均经过加密处理</span>
                                </div>
                            </div>
                        </div>
                    </form>
                    <?php else : ?>
                    <!-- 自动提交表单到支付网关 -->
                    <div class="py-8 text-center">
                        <div class="inline-block animate-spin rounded-full h-8 w-8 border-4 border-primary border-t-transparent mb-3"></div>
                        <h3 class="text-base font-medium text-neutral-700 mb-2">正在跳转到支付页面</h3>
                        <p class="text-neutral-500 text-sm">如未自动跳转，请点击下方按钮</p>
                        <form id="payForm" action="<?= $config['api_url'] ?>" method="post" class="mt-4" target="_blank">
                            <?php foreach ($data as $k => $v) : ?>
                                <input type="hidden" name="<?= htmlspecialchars($k) ?>" value="<?= htmlspecialchars($v) ?>">
                            <?php endforeach; ?>
                            <button type="submit" class="px-4 py-2 bg-primary text-white rounded-lg btn-hover text-sm">
                                立即支付
                            </button>
                        </form>
                    </div>
                    <script>document.getElementById('payForm').submit();</script>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- 禁止F12和右键点击的脚本 -->
    <script type="text/javascript">
        // 禁止右键点击
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });
        
        // 禁止F12键
        document.addEventListener('keydown', function(e) {
            if (e.keyCode === 123) {
                e.preventDefault();
            }
            if (e.ctrlKey && e.shiftKey && e.keyCode === 73) {
                e.preventDefault();
            }
            if (e.ctrlKey && e.keyCode === 85) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>