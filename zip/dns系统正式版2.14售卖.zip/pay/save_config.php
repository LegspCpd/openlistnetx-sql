<?php
// 接收JSON数据
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE);

// 引入配置文件
require_once 'config.php';

// 更新配置信息
$config['pid'] = $input['pid'];
$config['key'] = $input['key'];
$config['api_url'] = $input['api_url'];
$config['notify_url'] = $input['notify_url'];
$config['return_url'] = $input['return_url'];
$config['wxpay_enabled'] = $input['wxpay_enabled'];
$config['alipay_enabled'] = $input['alipay_enabled'];

// 将配置信息写入配置文件
$configContent = "<?php\n";
$configContent .= "\$home_url = (isset(\$_SERVER['HTTPS']) && \$_SERVER['HTTPS'] === 'on' ? \"https\" : \"http\") . \"://\" . \$_SERVER['HTTP_HOST'] . \"/\";\n";
$configContent .= "\$config = [\n";
$configContent .= "    'pid'         => " . $config['pid'] . ",\n";
$configContent .= "    'key'         => '" . $config['key'] . "',\n";
$configContent .= "    'api_url'     => '" . $config['api_url'] . "',\n";
$configContent .= "    'notify_url'  => \$home_url . 'pay/notify_url.php',\n";
$configContent .= "    'return_url'  => \$home_url . 'pay/return_url.php',\n";
$configContent .= "    'wxpay_enabled' => " . ($config['wxpay_enabled'] ? 'true' : 'false') . ",\n";
$configContent .= "    'alipay_enabled' => " . ($config['alipay_enabled'] ? 'true' : 'false') . "\n";
$configContent .= "];\n";
$configContent .= "?>";

// 写入文件
if (file_put_contents('config.php', $configContent)) {
    $response = [
        'success' => true,
        'message' => '配置保存成功'
    ];
} else {
    $response = [
        'success' => false,
        'message' => '配置保存失败'
    ];
}

// 返回JSON响应
header('Content-Type: application/json');
echo json_encode($response);
?>