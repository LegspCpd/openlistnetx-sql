<?php
$home_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://" . $_SERVER['HTTP_HOST'] . "/";
$config = [
    'pid'         => 1000,
    'key'         => 'hvHqC8ZOo4uSgcOQ0UoA4wH0vWCdD2RO',
    'api_url'     => 'https://xpay.01i0.icu/submit.php',
    'notify_url'  => $home_url . 'pay/notify_url.php',
    'return_url'  => $home_url . 'pay/return_url.php',
    'wxpay_enabled' => true,
    'alipay_enabled' => false
];
?>