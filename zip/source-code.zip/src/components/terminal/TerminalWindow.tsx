import type { ReactNode } from 'react';

interface TerminalWindowProps {
  children: ReactNode;
}

/** 终端窗口容器：标题栏 + 内容区 */
export function TerminalWindow({ children }: TerminalWindowProps) {
  return (
    <div className="w-full border border-border bg-card/90 shadow-[0_0_50px_hsl(120_100%_50%/0.08)] backdrop-blur-sm">
      {/* 标题栏 */}
      <div className="flex items-center gap-2 border-b border-border bg-secondary/70 px-3 py-2">
        <span className="h-3 w-3 shrink-0 rounded-full bg-destructive" />
        <span className="h-3 w-3 shrink-0 rounded-full bg-accent" />
        <span className="h-3 w-3 shrink-0 rounded-full bg-primary" />
        <span className="ml-2 truncate text-xs text-muted-foreground">
          sb@geek-terminal: ~/resume
        </span>
      </div>
      {/* 内容区 */}
      <div className="p-3 text-sm md:p-5 md:text-base">{children}</div>
    </div>
  );
}