import { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils';
import type { TermTone } from '@/lib/resume';

interface TypewriterLineProps {
  text: string;
  tone?: TermTone;
  speed?: number;
  showCursor?: boolean;
  onTick?: () => void;
  onComplete?: () => void;
}

const toneClass: Record<TermTone, string> = {
  green: 'text-primary text-glow',
  amber: 'text-accent text-glow-amber',
  cyan: 'text-terminal-cyan text-glow-cyan',
  dim: 'text-muted-foreground',
};

/** 单行打字机组件：逐字输出文本，完成后回调 */
export function TypewriterLine({
  text,
  tone = 'green',
  speed = 24,
  showCursor = false,
  onTick,
  onComplete,
}: TypewriterLineProps) {
  const [count, setCount] = useState(0);
  const doneRef = useRef(false);
  const onTickRef = useRef(onTick);
  const onCompleteRef = useRef(onComplete);
  onTickRef.current = onTick;
  onCompleteRef.current = onComplete;

  useEffect(() => {
    if (count >= text.length) {
      if (!doneRef.current) {
        doneRef.current = true;
        onCompleteRef.current?.();
      }
      return;
    }
    const timer = setTimeout(() => {
      setCount((c) => c + 1);
      onTickRef.current?.();
    }, speed);
    return () => clearTimeout(timer);
  }, [count, text.length, speed]);

  const shown = text.slice(0, count);

  return (
    <div className="min-h-[1.25em] whitespace-pre-wrap break-words leading-relaxed">
      <span className={cn(toneClass[tone])}>{shown}</span>
      {showCursor && (
        <span className="ml-0.5 inline-block h-[1em] w-[0.55em] translate-y-[0.15em] bg-primary align-middle animate-cursor-blink" />
      )}
    </div>
  );
}