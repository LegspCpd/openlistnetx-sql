import { useEffect, useRef, useState } from 'react';
import { TypewriterLine } from './TypewriterLine';
import type { TermLine } from '@/lib/resume';

interface TerminalSequenceProps {
  lines: TermLine[];
}

/** 终端输出序列：逐行打字，自动滚动到底部 */
export function TerminalSequence({ lines }: TerminalSequenceProps) {
  const [visible, setVisible] = useState(1);
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  };

  useEffect(() => {
    scrollToBottom();
  }, [visible]);

  return (
    <div ref={scrollRef} className="max-h-[70vh] overflow-y-auto md:max-h-[72vh]">
      {lines.slice(0, visible).map((line, index) => {
        const isLast = index === visible - 1;
        return (
          <TypewriterLine
            key={line.id}
            text={line.text}
            tone={line.tone}
            speed={line.speed}
            showCursor={isLast}
            onTick={scrollToBottom}
            onComplete={() => {
              if (visible < lines.length) {
                setVisible((v) => v + 1);
              }
            }}
          />
        );
      })}
    </div>
  );
}