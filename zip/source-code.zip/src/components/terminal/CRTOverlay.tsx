/** CRT 显示器视觉叠加层：扫描线 + 暗角 */
export function CRTOverlay() {
  return (
    <>
      <div className="pointer-events-none fixed inset-0 z-40 crt-scanlines" />
      <div className="pointer-events-none fixed inset-0 z-40 crt-vignette" />
    </>
  );
}