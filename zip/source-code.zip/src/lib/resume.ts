export type TermTone = 'green' | 'amber' | 'cyan' | 'dim';

export interface TermLine {
  id: string;
  text: string;
  tone?: TermTone;
  speed?: number;
}

/** 极客终端风格简历内容 —— 命令行输出序列 */
export const resumeLines: TermLine[] = [
  // ── 系统启动序列 ──
  { id: 'boot-1', text: 'GNU bash, version 5.2.0(1)-release', tone: 'dim', speed: 14 },
  { id: 'boot-2', text: '正在初始化终端会话...', tone: 'dim', speed: 18 },
  { id: 'boot-3', text: '加载简历模块 [████████████] 100%', tone: 'dim', speed: 16 },
  { id: 'boot-4', text: '连接已建立。欢迎回来，操作员。', tone: 'green', speed: 20 },
  { id: 'boot-5', text: '', tone: 'dim', speed: 10 },

  // ── whoami ──
  { id: 'whoami-cmd', text: 'sb@geek-terminal:~$ whoami', tone: 'green', speed: 30 },
  { id: 'whoami-out', text: '我是sb', tone: 'amber', speed: 60 },
  { id: 'whoami-blank', text: '', tone: 'dim', speed: 10 },

  // ── profile ──
  { id: 'prof-cmd', text: 'sb@geek-terminal:~$ cat profile.txt', tone: 'green', speed: 26 },
  { id: 'prof-hdr', text: '═══════ 个人档案 ═══════', tone: 'cyan', speed: 18 },
  { id: 'prof-1', text: '姓名      : 我是sb', tone: 'green', speed: 18 },
  { id: 'prof-2', text: '身份      : 全栈开发者 / 数字游民', tone: 'green', speed: 18 },
  { id: 'prof-3', text: '座右铭    : Talk is cheap, show me the code.', tone: 'amber', speed: 18 },
  { id: 'prof-4', text: '简介      : 热爱用代码解决问题，沉迷于把复杂的事情变简单。', tone: 'dim', speed: 16 },
  { id: 'prof-blank', text: '', tone: 'dim', speed: 10 },

  // ── skills ──
  { id: 'sk-cmd', text: 'sb@geek-terminal:~$ cat skills.json', tone: 'green', speed: 26 },
  { id: 'sk-hdr', text: '═══════ 技能树 ═══════', tone: 'cyan', speed: 18 },
  { id: 'sk-1', text: 'Languages : TypeScript, Python, Go, Rust, C++', tone: 'green', speed: 16 },
  { id: 'sk-2', text: 'Frontend  : React, Vue, Next.js, TailwindCSS', tone: 'green', speed: 16 },
  { id: 'sk-3', text: 'Backend   : Node.js, FastAPI, PostgreSQL, Redis', tone: 'green', speed: 16 },
  { id: 'sk-4', text: 'DevOps    : Docker, Kubernetes, CI/CD, Linux', tone: 'green', speed: 16 },
  { id: 'sk-5', text: 'Tools     : Git, Vim, Neovim, tmux, VSCode', tone: 'green', speed: 16 },
  { id: 'sk-blank', text: '', tone: 'dim', speed: 10 },

  // ── experience ──
  { id: 'ex-cmd', text: 'sb@geek-terminal:~$ cat experience.log', tone: 'green', speed: 26 },
  { id: 'ex-hdr', text: '═══════ 工作经历 ═══════', tone: 'cyan', speed: 18 },
  { id: 'ex-1', text: '[2023 - 至今] 高级全栈工程师 @ 某科技公司', tone: 'amber', speed: 18 },
  { id: 'ex-1a', text: '  - 主导核心业务系统重构，整体性能提升 40%', tone: 'dim', speed: 16 },
  { id: 'ex-1b', text: '  - 搭建微服务架构，支撑日均千万级请求', tone: 'dim', speed: 16 },
  { id: 'ex-2', text: '[2021 - 2023] 后端开发工程师 @ 某互联网公司', tone: 'amber', speed: 18 },
  { id: 'ex-2a', text: '  - 设计并实现高并发支付系统，零故障上线', tone: 'dim', speed: 16 },
  { id: 'ex-2b', text: '  - 优化数据库查询，接口响应缩短 60%', tone: 'dim', speed: 16 },
  { id: 'ex-blank', text: '', tone: 'dim', speed: 10 },

  // ── projects ──
  { id: 'pj-cmd', text: 'sb@geek-terminal:~$ ls projects/', tone: 'green', speed: 26 },
  { id: 'pj-hdr', text: '═══════ 项目经历 ═══════', tone: 'cyan', speed: 18 },
  { id: 'pj-1', text: '1. 极客终端简历  - 你正在看的这个 :)', tone: 'green', speed: 18 },
  { id: 'pj-2', text: '2. 开源工具集    - GitHub 上 2k+ star', tone: 'green', speed: 18 },
  { id: 'pj-3', text: '3. 实时协作编辑器 - 基于 CRDT 算法', tone: 'green', speed: 18 },
  { id: 'pj-4', text: '4. AI 代码助手    - 接入大模型的开发插件', tone: 'green', speed: 18 },
  { id: 'pj-blank', text: '', tone: 'dim', speed: 10 },

  // ── education ──
  { id: 'ed-cmd', text: 'sb@geek-terminal:~$ cat education.md', tone: 'green', speed: 26 },
  { id: 'ed-hdr', text: '═══════ 教育背景 ═══════', tone: 'cyan', speed: 18 },
  { id: 'ed-1', text: '[2017 - 2021] 某大学 计算机科学与技术 学士', tone: 'amber', speed: 18 },
  { id: 'ed-1a', text: '  GPA 3.8/4.0 | ACM 校队成员', tone: 'dim', speed: 16 },
  { id: 'ed-blank', text: '', tone: 'dim', speed: 10 },

  // ── contact ──
  { id: 'ct-cmd', text: 'sb@geek-terminal:~$ cat contact.txt', tone: 'green', speed: 26 },
  { id: 'ct-hdr', text: '═══════ 联系方式 ═══════', tone: 'cyan', speed: 18 },
  { id: 'ct-1', text: 'Email     : hello@sb.dev', tone: 'green', speed: 18 },
  { id: 'ct-2', text: 'GitHub    : github.com/iam-sb', tone: 'green', speed: 18 },
  { id: 'ct-3', text: 'Website   : sb.dev', tone: 'green', speed: 18 },
  { id: 'ct-blank', text: '', tone: 'dim', speed: 10 },

  // ── 结束 ──
  { id: 'end-1', text: 'sb@geek-terminal:~$ echo "简历加载完毕，期待与你相遇。"', tone: 'green', speed: 24 },
  { id: 'end-2', text: '简历加载完毕，期待与你相遇。', tone: 'amber', speed: 30 },
  { id: 'end-blank', text: '', tone: 'dim', speed: 10 },
  { id: 'end-prompt', text: 'sb@geek-terminal:~$ ', tone: 'green', speed: 40 },
];