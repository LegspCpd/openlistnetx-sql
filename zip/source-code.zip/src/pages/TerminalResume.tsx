import { useEffect } from 'react';
import { CRTOverlay } from '@/components/terminal/CRTOverlay';
import { TerminalWindow } from '@/components/terminal/TerminalWindow';
import { TerminalSequence } from '@/components/terminal/TerminalSequence';
import { resumeLines } from '@/lib/resume';

export default function TerminalResume() {
  useEffect(() => {
    document.title = '我是sb · 极客终端';
  }, []);

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden bg-background animate-crt-flicker">
      <CRTOverlay />

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-4xl flex-col px-3 py-4 md:px-6 md:py-8">
        {/* 顶部标识 */}
        <div className="mb-3 flex items-center gap-2 px-1">
          <span className="font-pixel text-base text-primary text-glow md:text-lg">
            {'>'} SB-TERMINAL v1.0
          </span>
        </div>

        <TerminalWindow>
          <TerminalSequence lines={resumeLines} />
        </TerminalWindow>

        <footer className="mt-4 px-1 text-center text-xs text-muted-foreground">
          <span>© 2026 我是sb — powered by caffeine &amp; terminal magic</span>
        </footer>
      </div>
    </div>
  );
}